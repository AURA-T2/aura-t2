package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ==========================================
// 1. DATABASE ENTITIES
// ==========================================

@Entity(tableName = "matches")
data class MatchEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val type: String, // SOLO, DUO, SQUAD
    val map: String, // BERMUDA, PURGATORY, KALAHARI, ALPINE
    val entryFee: Int,
    val prizePool: Int,
    val perKill: Int,
    val matchTime: String, // BENGALI time e.g. "১৫ জুন, রাত ০৯:০০"
    val totalSlots: Int = 48,
    val joinedSlots: Int = 0,
    val status: String, // UPCOMING, ONGOING, COMPLETED
    val roomID: String? = null,
    val roomPassword: String? = null,
    val booyahPlayer: String? = null,
    val booyahKills: Int? = null,
    val topKillsPlayer: String? = null,
    val topKillsCount: Int? = null,
    val isVillageMatch: Boolean = false,
    val rules: String = "",
    val isFree: Boolean = false
)

@Entity(tableName = "user_wallet")
data class UserWalletEntity(
    @PrimaryKey val id: Int = 1,
    val inGameName: String,
    val playerUid: String,
    val balance: Double,
    val phone: String,
    val realName: String = "",
    val village: String = "",
    val registeredAt: Long = 0L
)

@Entity(tableName = "registrations")
data class RegistrationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val matchId: Int,
    val playerUid: String,
    val playerName: String,
    val squadName: String? = null,
    val registeredAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // DEPOSIT, WITHDRAW, JOIN_FEE
    val amount: Double,
    val status: String, // PENDING, SUCCESS, REJECTED
    val method: String, // bKash, Nagad, Rocket
    val accountNo: String,
    val transactionId: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "leaderboard_players")
data class LeaderboardPlayerEntity(
    @PrimaryKey val serialNumber: Int,
    val name: String,
    val wins: Int,
    val losses: Int,
    val playerUid: String,
    val phone: String,
    val balance: Double,
    val realName: String = "",
    val village: String = "",
    val joiningTimestamp: Long = 0L
)

@Entity(tableName = "notices")
data class NoticeEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val likes: Int = 0,
    val dislikes: Int = 0,
    val votedUserIds: String = "" // List of playerUids separated by comma
)

// ==========================================
// 2. DATA ACCESS OBJECT (DAO)
// ==========================================

@Dao
interface TournamentDao {
    @Query("SELECT * FROM matches ORDER BY id DESC")
    fun getAllMatches(): Flow<List<MatchEntity>>

    @Query("SELECT * FROM matches WHERE id = :matchId")
    fun getMatchById(matchId: Int): Flow<MatchEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(match: MatchEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatches(matches: List<MatchEntity>)

    @Update
    suspend fun updateMatch(match: MatchEntity)

    @Query("SELECT * FROM user_wallet WHERE id = 1")
    fun getUserWallet(): Flow<UserWalletEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserWallet(wallet: UserWalletEntity)

    @Update
    suspend fun updateUserWallet(wallet: UserWalletEntity)

    @Query("SELECT * FROM registrations WHERE matchId = :matchId")
    fun getRegistrationsForMatch(matchId: Int): Flow<List<RegistrationEntity>>

    @Query("SELECT * FROM registrations WHERE matchId = :matchId AND playerUid = :playerUid LIMIT 1")
    fun getRegistrationOfUser(matchId: Int, playerUid: String): Flow<RegistrationEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRegistration(registration: RegistrationEntity)

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id")
    suspend fun getTransactionById(id: Int): TransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    @Query("SELECT * FROM leaderboard_players ORDER BY serialNumber ASC")
    fun getAllLeaderboardPlayers(): Flow<List<LeaderboardPlayerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaderboardPlayers(players: List<LeaderboardPlayerEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaderboardPlayer(player: LeaderboardPlayerEntity)

    @Update
    suspend fun updateLeaderboardPlayer(player: LeaderboardPlayerEntity)

    @Query("SELECT * FROM notices ORDER BY id DESC")
    fun getAllNotices(): Flow<List<NoticeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotice(notice: NoticeEntity)

    @Update
    suspend fun updateNotice(notice: NoticeEntity)

    @Query("DELETE FROM notices WHERE id = :id")
    suspend fun deleteNotice(id: Int)
}

// ==========================================
// 3. ROOM DATABASE CLASS
// ==========================================

@Database(
    entities = [
        MatchEntity::class,
        UserWalletEntity::class,
        RegistrationEntity::class,
        TransactionEntity::class,
        LeaderboardPlayerEntity::class,
        NoticeEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tournamentDao(): TournamentDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "aura_t2_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// ==========================================
// 4. TOURNAMENT REPOSITORY
// ==========================================

class TournamentRepository(private val tournamentDao: TournamentDao) {

    val allMatches: Flow<List<MatchEntity>> = tournamentDao.getAllMatches()
    val userWallet: Flow<UserWalletEntity?> = tournamentDao.getUserWallet()
    val allTransactions: Flow<List<TransactionEntity>> = tournamentDao.getAllTransactions()
    val allLeaderboardPlayers: Flow<List<LeaderboardPlayerEntity>> = tournamentDao.getAllLeaderboardPlayers()
    val allNotices: Flow<List<NoticeEntity>> = tournamentDao.getAllNotices()

    suspend fun addNotice(notice: NoticeEntity) {
        tournamentDao.insertNotice(notice)
    }

    suspend fun updateNotice(notice: NoticeEntity) {
        tournamentDao.updateNotice(notice)
    }

    suspend fun deleteNotice(id: Int) {
        tournamentDao.deleteNotice(id)
    }

    fun getMatch(matchId: Int): Flow<MatchEntity?> = tournamentDao.getMatchById(matchId)
    
    fun getRegistrations(matchId: Int): Flow<List<RegistrationEntity>> = 
        tournamentDao.getRegistrationsForMatch(matchId)

    fun isUserRegistered(matchId: Int, playerUid: String): Flow<RegistrationEntity?> =
        tournamentDao.getRegistrationOfUser(matchId, playerUid)

    suspend fun registerForMatch(
        match: MatchEntity,
        wallet: UserWalletEntity,
        playerName: String,
        squadName: String?
    ): Boolean {
        if (wallet.balance < match.entryFee) return false
        if (match.joinedSlots >= match.totalSlots) return false

        // 1. Deduct balance from user wallet
        val updatedWallet = wallet.copy(balance = wallet.balance - match.entryFee)
        tournamentDao.insertUserWallet(updatedWallet)

        // 2. Add registration record
        val registration = RegistrationEntity(
            matchId = match.id,
            playerUid = wallet.playerUid,
            playerName = playerName,
            squadName = squadName
        )
        tournamentDao.insertRegistration(registration)

        // 3. Update match joined slot count
        val updatedMatch = match.copy(joinedSlots = match.joinedSlots + 1)
        tournamentDao.updateMatch(updatedMatch)

        // 4. Add wallet transaction log
        val transaction = TransactionEntity(
            type = "JOIN_FEE",
            amount = match.entryFee.toDouble(),
            status = "SUCCESS",
            method = "WALLET",
            accountNo = wallet.playerUid,
            transactionId = "TXN-JOIN-${match.id}-${System.currentTimeMillis() % 100000}"
        )
        tournamentDao.insertTransaction(transaction)

        return true
    }

    suspend fun depositMoney(
        wallet: UserWalletEntity,
        amount: Double,
        method: String,
        senderNumber: String,
        transactionId: String
    ): Boolean {
        // Log transaction as pending
        val transaction = TransactionEntity(
            type = "DEPOSIT",
            amount = amount,
            status = "PENDING", // starts as PENDING until approved by admin
            method = method,
            accountNo = senderNumber,
            transactionId = transactionId
        )
        tournamentDao.insertTransaction(transaction)
        return true
    }

    suspend fun approveTransaction(id: Int): Boolean {
        val txn = tournamentDao.getTransactionById(id) ?: return false
        if (txn.status != "PENDING") return false

        // Update transaction status
        val updatedTxn = txn.copy(status = "SUCCESS")
        tournamentDao.insertTransaction(updatedTxn)

        // If deposit, credit wallet balance
        if (txn.type == "DEPOSIT") {
            val wallet = tournamentDao.getUserWallet().firstOrNull()
            if (wallet != null) {
                val updatedWallet = wallet.copy(balance = wallet.balance + txn.amount)
                tournamentDao.insertUserWallet(updatedWallet)
            }
        }
        return true
    }

    suspend fun rejectTransaction(id: Int): Boolean {
        val txn = tournamentDao.getTransactionById(id) ?: return false
        if (txn.status != "PENDING") return false

        // Update transaction status
        val updatedTxn = txn.copy(status = "REJECTED")
        tournamentDao.insertTransaction(updatedTxn)

        // If withdrawal, refund balance
        if (txn.type == "WITHDRAW") {
            val wallet = tournamentDao.getUserWallet().firstOrNull()
            if (wallet != null) {
                val updatedWallet = wallet.copy(balance = wallet.balance + txn.amount)
                tournamentDao.insertUserWallet(updatedWallet)
            }
        }
        return true
    }

    suspend fun addTournament(match: MatchEntity) {
        tournamentDao.insertMatch(match)
    }

    suspend fun addTrialBalance(amount: Double): Boolean {
        val wallet = tournamentDao.getUserWallet().firstOrNull() ?: return false
        val updatedWallet = wallet.copy(balance = wallet.balance + amount)
        tournamentDao.insertUserWallet(updatedWallet)

        val txn = TransactionEntity(
            type = "DEPOSIT",
            amount = amount,
            status = "SUCCESS",
            method = "Trial Balance",
            accountNo = "AURA-ADMIN",
            transactionId = "GIFT-${System.currentTimeMillis() % 100000}"
        )
        tournamentDao.insertTransaction(txn)
        return true
    }

    suspend fun withdrawMoney(
        wallet: UserWalletEntity,
        amount: Double,
        method: String,
        receiverNumber: String
    ): Boolean {
        if (wallet.balance < amount) return false

        // Deduct from wallet instantly
        val updatedWallet = wallet.copy(balance = wallet.balance - amount)
        tournamentDao.insertUserWallet(updatedWallet)

        // Log transaction as pending
        val transaction = TransactionEntity(
            type = "WITHDRAW",
            amount = amount,
            status = "PENDING", // withdrawal starts as pending
            method = method,
            accountNo = receiverNumber,
            transactionId = "TXN-WD-${System.currentTimeMillis() % 100000}"
        )
        tournamentDao.insertTransaction(transaction)
        return true
    }

    suspend fun updateProfile(realName: String, village: String, uid: String, ign: String, phone: String) {
        val current = tournamentDao.getUserWallet().firstOrNull()
        val regAt = if (current != null && current.registeredAt != 0L) current.registeredAt else System.currentTimeMillis()
        val balanceVal = current?.balance ?: 100.0
        
        val updated = UserWalletEntity(
            id = 1,
            inGameName = ign,
            playerUid = uid,
            balance = balanceVal,
            phone = phone,
            realName = realName,
            village = village,
            registeredAt = regAt
        )
        tournamentDao.insertUserWallet(updated)

        // Seed/Update user in leaderboard table too as player 1251
        val userLeaderboard = LeaderboardPlayerEntity(
            serialNumber = 1251,
            name = ign,
            wins = 3,
            losses = 1,
            playerUid = uid,
            phone = phone,
            balance = balanceVal,
            realName = realName,
            village = village,
            joiningTimestamp = regAt
        )
        tournamentDao.insertLeaderboardPlayer(userLeaderboard)
    }

    suspend fun updateLeaderboardPlayer(player: LeaderboardPlayerEntity) {
        tournamentDao.updateLeaderboardPlayer(player)
    }

    suspend fun prepopulateDatabase() {
        val currentWallet = tournamentDao.getUserWallet().firstOrNull()
        if (currentWallet == null) {
            // Seed a starter user wallet with empty names so players register first
            tournamentDao.insertUserWallet(
                UserWalletEntity(
                    inGameName = "",
                    playerUid = "",
                    balance = 120.0, // 120 BDT starter balance for easily registering for multiple games
                    phone = "",
                    realName = "",
                    village = "",
                    registeredAt = 0L
                )
            )
        }

        val currentLeaderboard = tournamentDao.getAllLeaderboardPlayers().firstOrNull()
        if (currentLeaderboard == null || currentLeaderboard.isEmpty()) {
            val sampleLeaderboard = listOf(
                LeaderboardPlayerEntity(serialNumber = 1, name = "SHADOW_BOSS", wins = 24, losses = 3, playerUid = "FF9214051B", phone = "01723498124", balance = 550.0, realName = "মো: শাকিল আহমেদ", village = "উত্তরা সেকশন ৪", joiningTimestamp = System.currentTimeMillis() - 86400000L * 15),
                LeaderboardPlayerEntity(serialNumber = 2, name = "Aura_Rafi_YT", wins = 20, losses = 4, playerUid = "FF39182390", phone = "01855219385", balance = 320.0, realName = "রাফিউর রহমান", village = "কাজীপাড়া", joiningTimestamp = System.currentTimeMillis() - 86400000L * 14),
                LeaderboardPlayerEntity(serialNumber = 3, name = "Kazi_Squad_Leader", wins = 18, losses = 5, playerUid = "FF83109282", phone = "01933221144", balance = 400.0, realName = "কাজী আসিফ", village = "রামপুরা", joiningTimestamp = System.currentTimeMillis() - 86400000L * 13),
                LeaderboardPlayerEntity(serialNumber = 4, name = "OP_BOOYAH", wins = 16, losses = 6, playerUid = "FF49830591", phone = "01522883344", balance = 180.0, realName = "মেহেদী হাসান", village = "কালীগঞ্জ গ্রাম", joiningTimestamp = System.currentTimeMillis() - 86400000L * 12),
                LeaderboardPlayerEntity(serialNumber = 12, name = "Gamer_Rony", wins = 14, losses = 5, playerUid = "FF29184013", phone = "01755663366", balance = 110.0, realName = "রনি আহমেদ", village = "বাসাবো", joiningTimestamp = System.currentTimeMillis() - 86400000L * 11),
                LeaderboardPlayerEntity(serialNumber = 18, name = "T2_Chucker", wins = 12, losses = 4, playerUid = "FF11029837", phone = "01309874561", balance = 90.0, realName = "চৌধুরী মো: তাসনিম", village = "উত্তরা সেকশন ১০", joiningTimestamp = System.currentTimeMillis() - 86400000L * 10),
                LeaderboardPlayerEntity(serialNumber = 24, name = "FF_Srabon", wins = 11, losses = 6, playerUid = "FF55610293", phone = "01824123547", balance = 150.0, realName = "শ্রাবণ রহমান", village = "মিরপুর সেকশন ১", joiningTimestamp = System.currentTimeMillis() - 86400000L * 9),
                LeaderboardPlayerEntity(serialNumber = 37, name = "Section_Hitter", wins = 10, losses = 7, playerUid = "FF36928104", phone = "01928374162", balance = 210.0, realName = "ইনজামামুল হক", village = "খিলগাঁও", joiningTimestamp = System.currentTimeMillis() - 86400000L * 8),
                LeaderboardPlayerEntity(serialNumber = 42, name = "Village_King", wins = 9, losses = 4, playerUid = "FF82930192", phone = "01736192837", balance = 80.0, realName = "রাজু মোল্লা", village = "কালীগঞ্জ গ্রাম", joiningTimestamp = System.currentTimeMillis() - 86400000L * 7),
                LeaderboardPlayerEntity(serialNumber = 55, name = "AURA_NABIL", wins = 8, losses = 5, playerUid = "FF91283746", phone = "01567123456", balance = 300.0, realName = "নাবিল চৌধুরী", village = "ধানমন্ডি", joiningTimestamp = System.currentTimeMillis() - 86400000L * 6),
                LeaderboardPlayerEntity(serialNumber = 102, name = "Noob_Ami", wins = 6, losses = 8, playerUid = "FF09182736", phone = "01323456789", balance = 50.0, realName = "মো: সাব্বির", village = "বনশ্রী", joiningTimestamp = System.currentTimeMillis() - 86400000L * 5),
                LeaderboardPlayerEntity(serialNumber = 250, name = "Apex_Legend", wins = 5, losses = 3, playerUid = "FF19182731", phone = "01711122233", balance = 130.0, realName = "জাবেদ ইকবাল", village = "উত্তরা সেকশন ১৪", joiningTimestamp = System.currentTimeMillis() - 86400000L * 4),
                LeaderboardPlayerEntity(serialNumber = 580, name = "Deadly_Storm", wins = 4, losses = 4, playerUid = "FF28193820", phone = "01811223344", balance = 95.0, realName = "ঝড়ো হাওয়া রকি", village = "সাভার", joiningTimestamp = System.currentTimeMillis() - 86400000L * 3),
                LeaderboardPlayerEntity(serialNumber = 999, name = "Fire_Sniper", wins = 3, losses = 5, playerUid = "FF48192039", phone = "01911223344", balance = 75.0, realName = "নাঈম হোসাইন", village = "টঙ্গী", joiningTimestamp = System.currentTimeMillis() - 86400000L * 2),
                LeaderboardPlayerEntity(serialNumber = 1212, name = "Bengali_Hero", wins = 2, losses = 6, playerUid = "FF78192048", phone = "01511223344", balance = 40.0, realName = "বীর বাঙালি আকাশ", village = "কেরানীগঞ্জ", joiningTimestamp = System.currentTimeMillis() - 86400000L * 1)
            )
            tournamentDao.insertLeaderboardPlayers(sampleLeaderboard)
        }

        val currentMatches = tournamentDao.getAllMatches().firstOrNull()
        if (currentMatches == null || currentMatches.isEmpty()) {
            val sampleMatches = listOf(
                MatchEntity(
                    title = "AURA T2 - দৈনিক স্পেশাল সলো",
                    type = "SOLO",
                    map = "BERMUDA",
                    entryFee = 20,
                    prizePool = 500,
                    perKill = 5,
                    matchTime = "১৫ জুন, রাত ০৮:০০",
                    totalSlots = 48,
                    joinedSlots = 24,
                    status = "UPCOMING",
                    roomID = "5281403",
                    roomPassword = "aura123_coming_soon",
                    rules = "১. কোনো ধরনের এমুলেটর বা থার্ড পার্টি টুল ব্যবহার নিষিদ্ধ।\n২. হ্যাকার বা গ্লিচ ইউজার প্রমানিত হলে লাইফটাইম ব্যান করা হবে।\n৩. ম্যাচের কাস্টম রুমে সঠিক সময়ে প্রবেশ করতে হবে।",
                    isFree = false
                ),
                MatchEntity(
                    title = "AURA T2 - প্রো স্কোয়াড শোডাউন",
                    type = "SQUAD",
                    map = "PURGATORY",
                    entryFee = 80,
                    prizePool = 2000,
                    perKill = 20,
                    matchTime = "১৬ জুন, বিকাল ০৪:৩০",
                    totalSlots = 12,
                    joinedSlots = 4,
                    status = "UPCOMING",
                    roomID = "4815021",
                    roomPassword = "aura_squad_play",
                    rules = "১. ৪ জনের সম্পূর্ণ স্কোয়াড থাকতে হবে।\n২. গ্রুপে ফ্রেন্ডলি ফায়ার বা টিম ক্র্যাশ দেখা গেলে কোনো রিফান্ড দেয়া হবে না।\n৩. বিজয়ী দলের স্ক্রিনশট গ্রুপে আপলোড দিতে হবে।",
                    isFree = false
                ),
                MatchEntity(
                    title = "AURA T2 - কালাহারি ডুও ব্যাটল",
                    type = "DUO",
                    map = "KALAHARI",
                    entryFee = 30,
                    prizePool = 800,
                    perKill = 10,
                    matchTime = "১৭ জুন, রাত ০৯:৩০",
                    totalSlots = 25,
                    joinedSlots = 11,
                    status = "UPCOMING",
                    roomID = "3319082",
                    roomPassword = "aura_duo_kalahari",
                    rules = "১. ডুও টিম হতে হবে। অতিরিক্ত প্লেয়ার রুমে এলাউড নয়।\n২. কোনো টিমিং (Teaming up) সহ্য করা হবে না। প্রমান পেলে সরাসরি ডিসকোয়ালিফাই।",
                    isFree = false
                ),
                MatchEntity(
                    title = "AURA T2 - সলো কাপ ফাইনাল",
                    type = "SOLO",
                    map = "BERMUDA",
                    entryFee = 50,
                    prizePool = 1500,
                    perKill = 15,
                    matchTime = "১৫ জুন, দুপুর ০৩:০০",
                    totalSlots = 48,
                    joinedSlots = 48,
                    status = "ONGOING",
                    roomID = "225102",
                    roomPassword = "aura_solo_finals",
                    rules = "১. সলো ফাইনাল কাপ! সবার জন্য সমান সুযোগ।\n২. স্ক্রিনশট বা স্ট্রিমিং দেখে চিটিং করলে অ্যাকাউন্ট ব্লক করা হবে।",
                    isFree = false
                ),
                MatchEntity(
                    title = "Village vs Section - Match #03 🆓",
                    type = "SOLO",
                    map = "BERMUDA",
                    entryFee = 0,
                    prizePool = 300,
                    perKill = 3,
                    matchTime = "১৮ জুন, রাত ১০:০০",
                    totalSlots = 48,
                    joinedSlots = 12,
                    status = "UPCOMING",
                    roomID = "102830",
                    roomPassword = "free_solo_match",
                    rules = "১. ১টি সম্পূর্ণ ফ্রি ট্রায়াল ম্যাচ! কোনো প্রবেশ ফি লাগবে না।\n২. তবে বিজয়ী ব্যক্তি তার পুরস্কারের ব্যালেন্স ওয়ালেটে সাথে সাথে পেয়ে যাবেন!",
                    isFree = true
                ),
                MatchEntity(
                    title = "AURA T2 - ওপেনিং চ্যাম্পিয়নশিপ",
                    type = "SQUAD",
                    map = "BERMUDA",
                    entryFee = 50,
                    prizePool = 3000,
                    perKill = 25,
                    matchTime = "১৩ জুন, রাত ০৯:০০",
                    totalSlots = 12,
                    joinedSlots = 12,
                    status = "COMPLETED",
                    booyahPlayer = "Kazi_Squad",
                    booyahKills = 14,
                    topKillsPlayer = "Aura_Rafi_YT",
                    topKillsCount = 9
                ),
                MatchEntity(
                    title = "AURA T2 - কালাহারি স্পিডরান",
                    type = "SOLO",
                    map = "KALAHARI",
                    entryFee = 15,
                    prizePool = 400,
                    perKill = 4,
                    matchTime = "১২ জুন, রাত ১০:১৫",
                    totalSlots = 48,
                    joinedSlots = 48,
                    status = "COMPLETED",
                    booyahPlayer = "SHADOW_BOSS",
                    booyahKills = 8,
                    topKillsPlayer = "SHADOW_BOSS",
                    topKillsCount = 8
                ),
                MatchEntity(
                    title = "Village vs Section - Match #01 🔰",
                    type = "SQUAD",
                    map = "BERMUDA",
                    entryFee = 40,
                    prizePool = 1200,
                    perKill = 10,
                    matchTime = "১৮ জুন, রাত ০৯:০০",
                    totalSlots = 12,
                    joinedSlots = 6,
                    status = "UPCOMING",
                    roomID = "7291880",
                    roomPassword = "aura_village_01",
                    isVillageMatch = true,
                    rules = "১. ৪ জন প্লেয়ারই একই গ্রামের বা এলাকার হতে হবে।\n২. গ্রামের সেরা কাস্টম শোডাউনে সবাইকে স্বাগতম!"
                ),
                MatchEntity(
                    title = "Village vs Section - Match #02 👑",
                    type = "SQUAD",
                    map = "PURGATORY",
                    entryFee = 60,
                    prizePool = 1800,
                    perKill = 15,
                    matchTime = "১৯ জুন, রাত ০৮:০০",
                    totalSlots = 12,
                    joinedSlots = 2,
                    status = "UPCOMING",
                    roomID = "8304928",
                    roomPassword = "aura_village_02",
                    isVillageMatch = true,
                    rules = "১. ৪ জন প্লেয়ারই একই গ্রামের বা এলাকার হতে হবে।\n২. গ্রামের সেরা কাস্টম শোডাউনে সবাইকে স্বাগতম!"
                )
            )
            tournamentDao.insertMatches(sampleMatches)

            // Seed some default transaction logs for realism
            tournamentDao.insertTransaction(
                TransactionEntity(
                    type = "DEPOSIT",
                    amount = 100.0,
                    status = "SUCCESS",
                    method = "bKash",
                    accountNo = "01799882233",
                    transactionId = "TRXN82098KBL"
                )
            )
            tournamentDao.insertTransaction(
                TransactionEntity(
                    type = "DEPOSIT",
                    amount = 20.0,
                    status = "SUCCESS",
                    method = "Nagad",
                    accountNo = "01911442255",
                    transactionId = "TRXN92839NJD"
                )
            )

            // Seed default notices
            val sampleNotices = listOf(
                NoticeEntity(
                    title = "স্বাগতম AURA T2 তে! 🎮",
                    content = "সবাইকে আমাদের নতুন গেমিং প্ল্যাটফর্মে স্বাগতম! কোনো সমস্যা ফেস করলে বা হেল্প লাগলে সরাসরি আমাদের হোয়াটসঅ্যাপ হেল্পলাইনে যোগাযোগ করতে পারেন। টুর্নামেন্টে জয়েন করে জিতে নিন আকর্ষণীয় পুরস্কার!",
                    likes = 28,
                    dislikes = 1
                ),
                NoticeEntity(
                    title = "নতুন নিয়মাবলী এবং সততা রক্ষা 📜",
                    content = "যেকোনো ম্যাচে হ্যাকিং, গ্লিচ অথবা এমুলেটর ব্যবহার সম্পূর্ণ নিষিদ্ধ। টুর্নামেন্টের সততা রক্ষা করতে অ্যাডমিন প্যানেল সবসময় স্পেক্টেটরে পর্যবেক্ষণ করে। অসাধু উপায় অবলম্বন করলে সরাসরি আইডি ব্যান করা হবে।",
                    likes = 15,
                    dislikes = 0
                )
            )
            for (notice in sampleNotices) {
                tournamentDao.insertNotice(notice)
            }
        }
    }
}
