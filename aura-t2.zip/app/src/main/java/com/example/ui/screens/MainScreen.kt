@file:OptIn(ExperimentalMaterial3Api::class)
package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import com.example.ui.theme.*
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.lazy.LazyRow
import com.example.data.MatchEntity
import com.example.data.TransactionEntity
import com.example.data.UserWalletEntity
import com.example.data.LeaderboardPlayerEntity
import com.example.ui.viewmodel.AppTab
import com.example.ui.viewmodel.TournamentUiState
import com.example.ui.viewmodel.TournamentViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainScreen(viewModel: TournamentViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()

    // Observe Event Messages from ViewModel for Instant Dynamic Feedbacks
    LaunchedEffect(Unit) {
        viewModel.eventMessage.collect { message ->
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090A10)), // Professional deep space background on laptops/PCs
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .widthIn(max = 640.dp)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "AURA T2",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 24.sp
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "PRO",
                                        color = MaterialTheme.colorScheme.tertiary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        },
                        actions = {
                            if (uiState is TournamentUiState.Success) {
                                val wallet = (uiState as TournamentUiState.Success).wallet
                                Surface(
                                    onClick = { viewModel.selectTab(AppTab.WALLET) },
                                    shape = RoundedCornerShape(20.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .padding(end = 12.dp)
                                        .testTag("top_bar_wallet_action")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AccountBalanceWallet,
                                            contentDescription = "Wallet Balance",
                                            tint = MaterialTheme.colorScheme.tertiary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = "৳ ${String.format(Locale.US, "%.0f", wallet.balance)}",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Icon(
                                            imageVector = Icons.Default.AddCircle,
                                            contentDescription = "Add cash",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background,
                            titleContentColor = Color.White
                        )
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        NavigationBarItem(
                            selected = currentTab == AppTab.HOME,
                            onClick = { viewModel.selectTab(AppTab.HOME) },
                            icon = { Icon(Icons.Default.Home, contentDescription = "হোম") },
                            label = { Text("হোম", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                unselectedIconColor = Color.Gray,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                unselectedTextColor = Color.Gray
                            ),
                            modifier = Modifier.testTag("navigation_tab_home")
                        )
                        NavigationBarItem(
                            selected = currentTab == AppTab.TOURNAMENTS,
                            onClick = { viewModel.selectTab(AppTab.TOURNAMENTS) },
                            icon = { Icon(Icons.Default.SportsEsports, contentDescription = "টুর্নামেন্ট") },
                            label = { Text("টুর্নামেন্ট", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                unselectedIconColor = Color.Gray,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                unselectedTextColor = Color.Gray
                            ),
                            modifier = Modifier.testTag("navigation_tab_tournaments")
                        )
                        NavigationBarItem(
                            selected = currentTab == AppTab.LEADERBOARD,
                            onClick = { viewModel.selectTab(AppTab.LEADERBOARD) },
                            icon = { Icon(Icons.Default.Leaderboard, contentDescription = "লিডারবোর্ড") },
                            label = { Text("লিডারবোর্ড", fontSize = 9.sp, fontWeight = FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                unselectedIconColor = Color.Gray,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                unselectedTextColor = Color.Gray
                            ),
                            modifier = Modifier.testTag("navigation_tab_leaderboard")
                        )
                        NavigationBarItem(
                            selected = currentTab == AppTab.RESULTS,
                            onClick = { viewModel.selectTab(AppTab.RESULTS) },
                            icon = { Icon(Icons.Default.EmojiEvents, contentDescription = "ফলাফল") },
                            label = { Text("ফলাফল", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                unselectedIconColor = Color.Gray,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                unselectedTextColor = Color.Gray
                            ),
                            modifier = Modifier.testTag("navigation_tab_results")
                        )
                        NavigationBarItem(
                            selected = currentTab == AppTab.WALLET,
                            onClick = { viewModel.selectTab(AppTab.WALLET) },
                            icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = "ওয়ালেট") },
                            label = { Text("ওয়ালেট", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                unselectedIconColor = Color.Gray,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                unselectedTextColor = Color.Gray
                            ),
                            modifier = Modifier.testTag("navigation_tab_wallet")
                        )
                        NavigationBarItem(
                            selected = currentTab == AppTab.RULES_SUPPORT,
                            onClick = { viewModel.selectTab(AppTab.RULES_SUPPORT) },
                            icon = { Icon(Icons.Default.Info, contentDescription = "সহায়তা") },
                            label = { Text("সহায়তা", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                unselectedIconColor = Color.Gray,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                unselectedTextColor = Color.Gray
                            ),
                            modifier = Modifier.testTag("navigation_tab_support")
                        )
                        NavigationBarItem(
                            selected = currentTab == AppTab.ADMIN,
                            onClick = { viewModel.selectTab(AppTab.ADMIN) },
                            icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = "অ্যাডমিন") },
                            label = { Text("অ্যাডমিন", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                unselectedIconColor = Color.Gray,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                unselectedTextColor = Color.Gray
                            ),
                            modifier = Modifier.testTag("navigation_tab_admin")
                        )
                    }
                },
                containerColor = MaterialTheme.colorScheme.background
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (uiState) {
                        is TournamentUiState.Loading -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        is TournamentUiState.Success -> {
                            val data = uiState as TournamentUiState.Success
                            AnimatedContent(
                                targetState = currentTab,
                                transitionSpec = {
                                    fadeIn() togetherWith fadeOut()
                                },
                                label = "TabTransition"
                            ) { tab ->
                                when (tab) {
                                    AppTab.HOME -> HomeTab(
                                        wallet = data.wallet,
                                        notices = data.notices,
                                        onVoteNotice = { noticeId, isLike, playerUid ->
                                            viewModel.voteNotice(noticeId, isLike, playerUid)
                                        }
                                    )
                                    AppTab.TOURNAMENTS -> TournamentsTab(
                                        matches = data.matches.filter { it.status != "COMPLETED" },
                                        wallet = data.wallet,
                                        onJoinMatch = { match, ign, squad ->
                                            viewModel.registerForMatch(match, ign, squad)
                                        },
                                        onUpdateProfile = { name, village, uid, ign, phone ->
                                            viewModel.updateProfile(name, village, uid, ign, phone)
                                        }
                                    )
                                    AppTab.LEADERBOARD -> LeaderboardTab(
                                        wallet = data.wallet
                                    )
                                    AppTab.RESULTS -> ResultsTab(
                                        completedMatches = data.matches.filter { it.status == "COMPLETED" }
                                    )
                                    AppTab.WALLET -> WalletTab(
                                        wallet = data.wallet,
                                        transactions = data.transactions,
                                        onUpdateProfile = { name, village, uid, ign, phone ->
                                            viewModel.updateProfile(name, village, uid, ign, phone)
                                        },
                                        onDeposit = { amount, method, sender, txnId ->
                                            viewModel.depositMoney(amount, method, sender, txnId)
                                        },
                                        onWithdraw = { amount, method, receiver ->
                                            viewModel.withdrawMoney(amount, method, receiver)
                                        }
                                    )
                                    AppTab.RULES_SUPPORT -> RulesSupportTab()
                                    AppTab.ADMIN -> AdminTab(
                                        wallet = data.wallet,
                                        matches = data.matches,
                                        transactions = data.transactions,
                                        leaderboardPlayers = data.leaderboardPlayers,
                                        notices = data.notices,
                                        onApproveTransaction = { id -> viewModel.approveTransaction(id) },
                                        onRejectTransaction = { id -> viewModel.rejectTransaction(id) },
                                        onAddTournament = { match -> viewModel.addTournament(match) },
                                        onGiveTrialBalance = { amt -> viewModel.addTrialBalance(amt) },
                                        onUpdateLeaderboardPlayer = { player -> viewModel.updateLeaderboardPlayer(player) },
                                        onAddNotice = { title, content -> viewModel.addNotice(title, content) },
                                        onDeleteNotice = { id -> viewModel.deleteNotice(id) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// TOURNAMENTS TAB
// ==========================================
@Composable
fun TournamentsTab(
    matches: List<MatchEntity>,
    wallet: UserWalletEntity,
    onJoinMatch: (MatchEntity, String, String?) -> Unit,
    onUpdateProfile: (String, String, String, String, String) -> Unit
) {
    val context = LocalContext.current
    var selectedCategoryFilter by remember { mutableStateOf("ALL") } // ALL, REGULAR, VILLAGE
    var selectedModeFilter by remember { mutableStateOf("ALL") } // ALL, SOLO, DUO, SQUAD
    var matchToJoin by remember { mutableStateOf<MatchEntity?>(null) }

    // Resolve our custom generated JPEG drawable
    val auraLogoResId = remember(context) {
        val id = context.resources.getIdentifier("aura_t2_logo_1781456162253", "drawable", context.packageName)
        if (id != 0) id else null
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Branding Header Panel
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.DarkGray)
            ) {
                if (auraLogoResId != null) {
                    Image(
                        painter = painterResource(id = auraLogoResId),
                        contentDescription = "AURA T2 Hero Logo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    // Fallback sleek neon canvas
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                                        MaterialTheme.colorScheme.surface
                                    )
                                )
                            )
                    )
                }

                // Sleek layout gradient cover to keep overlay readable
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                            )
                        )
                )

                // High intensity display typography
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "AURA T2 টুর্নামেন্ট",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 24.sp
                    )
                    Text(
                        text = "খেলুন এবং প্রতিদিন বিকাশ/নগদে টাকা জিতে নিন!",
                        color = MaterialTheme.colorScheme.secondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // AMAN ULLAH & MA-SAJEM administrative and ownership VIP bar
        item {
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF131622)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Stars, contentDescription = "Owner Icon", tint = Color(0xFFFFD700), modifier = Modifier.size(16.dp))
                            Text("APP OWNER", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 9.sp)
                        }
                        Text("MA-SAJEM", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    }
                    Box(modifier = Modifier.width(1.dp).height(32.dp).background(Color.Gray.copy(alpha = 0.3f)))
                    Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Security, contentDescription = "Admin Icon", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                            Text("CHIEF ADMIN", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                        }
                        Text("AMAN ULLAH", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    }
                }
            }
        }

        // Registration form or Player Profile card depending on realName existence
        val isRegistered = wallet.realName.isNotBlank() && wallet.village.isNotBlank()

        if (!isRegistered) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.PersonAdd,
                                contentDescription = "Register",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "প্লেয়ার প্রোফাইল রেজিস্ট্রেশন",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 15.sp
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        Text(
                            text = "আমাদের টুর্নামেন্টে খেলতে এবং লেনদেন করতে প্রথমে নিচে আপনার সঠিক তথ্যগুলো দিয়ে নিজের আইডি প্রোফাইল সাইনআপ করুন।",
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        var inputRealName by remember { mutableStateOf("") }
                        var inputVillage by remember { mutableStateOf("") }
                        var inputUid by remember { mutableStateOf("") }
                        var inputFfName by remember { mutableStateOf("") }
                        var inputPhone by remember { mutableStateOf("") }

                        OutlinedTextField(
                            value = inputRealName,
                            onValueChange = { inputRealName = it },
                            label = { Text("আপনার নাম (Real Name)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("reg_real_name"),
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp)) }
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = inputVillage,
                            onValueChange = { inputVillage = it },
                            label = { Text("আপনার গ্রাম (Village)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("reg_village"),
                            leadingIcon = { Icon(Icons.Default.Home, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp)) }
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = inputUid,
                            onValueChange = { inputUid = it },
                            label = { Text("ফ্রি ফায়ার ইউআইডি (UID)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("reg_uid"),
                            leadingIcon = { Icon(Icons.Default.Star, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp)) }
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = inputFfName,
                            onValueChange = { inputFfName = it },
                            label = { Text("ইন-গেম নাম (FF In-Game Name)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("reg_ff_name"),
                            leadingIcon = { Icon(Icons.Default.SportsEsports, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp)) }
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = inputPhone,
                            onValueChange = { inputPhone = it },
                            label = { Text("হোয়াটসঅ্যাপ বা মোবাইল নম্বর (Number)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("reg_number"),
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp)) }
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (inputRealName.isNotBlank() && inputVillage.isNotBlank() && inputUid.isNotBlank() && inputFfName.isNotBlank() && inputPhone.isNotBlank()) {
                                    onUpdateProfile(inputRealName.trim(), inputVillage.trim(), inputUid.trim(), inputFfName.trim(), inputPhone.trim())
                                } else {
                                    Toast.makeText(context, "দয়া করে প্রতিটি ঘর সঠিকভাবে সম্পন্ন করুন!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("reg_submit_button"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("নিবন্ধন সম্পন্ন করুন ✨", fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }
            }
        } else {
            // Displays player details card with wallet balance together
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F121C)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountCircle,
                                    contentDescription = "Profile Card Icon",
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Text(
                                    text = "আমার প্লেয়ার প্রোফাইল",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF00E676).copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "নিবন্ধিত প্লেয়ার (VERIFIED)",
                                    color = Color(0xFF00E676),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("নাম (Full Name)", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    Text(wallet.realName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("গ্রাম (Village)", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    Text(wallet.village, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }

                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.12f)))

                            Row(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("ফ্রি ফায়ার ইউআইডি (UID)", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    Text(wallet.playerUid, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("ইন-গেম নাম (FF In-Game Name)", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    Text(wallet.inGameName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }

                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.12f)))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("মোবাইল নম্বর (Number)", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    Text(wallet.phone, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                
                                // Wallet balance directly together in player profile
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AccountBalanceWallet,
                                            contentDescription = "Wallet Balance Icon",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Column {
                                            Text("ওয়ালেট ব্যালেন্স", color = Color.Gray, fontSize = 8.sp, fontWeight = FontWeight.Medium)
                                            Text("৳ ${String.format(Locale.US, "%.0f", wallet.balance)}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Beautiful System Notice Card about the Admin Tab
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "মাস্টার নোটিশ",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Column {
                        Text(
                            text = "📢 গুরুত্বপূর্ণ নোটিশ (অ্যাডমিন পোর্টাল)",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "নিচে থাকা ‘অ্যাডমিন’ ট্যাবটি এবং এর কন্ট্রোল প্যানেল শুধুমাত্র অফিশিয়াল অ্যাডমিনদের ব্যবহারের জন্য সুরক্ষিত। এই ট্যাবটি প্রবেশাধিকার সুরক্ষিত করতে সিক্রেট মাস্টার কোড দিয়ে লক করা থাকে। প্লেয়ারদের এতে কোনো কার্যক্রম নেই—যেকোনো পেমেন্ট বা টুর্নামেন্ট সমস্যা সহায়তার জন্য ‘সহায়তা’ ট্যাবে সরাসরি হোয়াটসঅ্যাপে যোগাযোগ করুন।",
                            color = Color.White,
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Horizontal Category Filter Pills
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Category Filter (Regular vs Village)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val categoryFilters = listOf(
                        "ALL" to "সব টুর্নামেন্ট 🎮",
                        "REGULAR" to "সাধারণ (Regular) ⭐️",
                        "VILLAGE" to "ভিলেজ (Village) 🏡"
                    )
                    categoryFilters.forEach { (key, label) ->
                        val isSelected = selectedCategoryFilter == key
                        ElevatedAssistChip(
                            onClick = { selectedCategoryFilter = key },
                            label = { Text(label, fontWeight = FontWeight.SemiBold, fontSize = 11.sp) },
                            colors = AssistChipDefaults.elevatedAssistChipColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                labelColor = if (isSelected) Color.Black else Color.LightGray
                            ),
                            border = if (isSelected) BorderStroke(1.dp, MaterialTheme.colorScheme.secondary) else null
                        )
                    }
                }

                // Mode Filter (Solo, Duo, Squad)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val modeFilters = listOf(
                        "ALL" to "সব মোড ⚔️",
                        "SOLO" to "সলো (Solo) 👤",
                        "DUO" to "ডুও (Duo) 👥",
                        "SQUAD" to "স্কোয়াড (Squad) 👨‍👩‍👦"
                    )
                    modeFilters.forEach { (key, label) ->
                        val isSelected = selectedModeFilter == key
                        ElevatedAssistChip(
                            onClick = { selectedModeFilter = key },
                            label = { Text(label, fontWeight = FontWeight.SemiBold, fontSize = 11.sp) },
                            colors = AssistChipDefaults.elevatedAssistChipColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                labelColor = if (isSelected) Color.Black else Color.LightGray
                            ),
                            border = if (isSelected) BorderStroke(1.dp, MaterialTheme.colorScheme.secondary) else null
                        )
                    }
                }
            }
        }

        // Filter Matches State
        val filteredMatches = matches.filter {
            val matchesCategory = when (selectedCategoryFilter) {
                "REGULAR" -> !it.isVillageMatch
                "VILLAGE" -> it.isVillageMatch
                else -> true
            }
            val matchesMode = selectedModeFilter == "ALL" || it.type == selectedModeFilter
            matchesCategory && matchesMode
        }

        if (filteredMatches.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.SportsEsports,
                            contentDescription = "No Matches Found",
                            tint = Color.Gray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "এই ক্যাটাগরিতে কোনো ম্যাচ পাওয়া যায়নি!",
                            color = Color.LightGray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(filteredMatches) { match ->
                MatchCard(
                    match = match,
                    wallet = wallet,
                    onJoinClick = { matchToJoin = match }
                )
            }
        }

        // Space at bottom for ergonomics
        item { Spacer(modifier = Modifier.height(16.dp)) }
    }

    // Join Match Confirmation Dialog
    matchToJoin?.let { match ->
        JoinMatchDialog(
            match = match,
            wallet = wallet,
            onDismiss = { matchToJoin = null },
            onConfirmJoin = { ign, squad ->
                onJoinMatch(match, ign, squad)
                matchToJoin = null
            }
        )
    }
}

// ==========================================
// HOME TAB
// ==========================================
@Composable
fun HomeTab(
    wallet: UserWalletEntity,
    notices: List<com.example.data.NoticeEntity>,
    onVoteNotice: (Int, Boolean, String) -> Unit
) {
    val context = LocalContext.current

    // Resolve our custom generated JPEG drawable
    val auraLogoResId = remember(context) {
        val id = context.resources.getIdentifier("aura_t2_logo_1781456162253", "drawable", context.packageName)
        if (id != 0) id else null
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Branding Logo Panel
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.DarkGray)
            ) {
                if (auraLogoResId != null) {
                    Image(
                        painter = painterResource(id = auraLogoResId),
                        contentDescription = "AURA T2 Hero Logo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    // Fallback gorgeous gradient background with logo simulation
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primary,
                                        Color(0xFF0F121C)
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "AURA T2",
                                style = TextStyle(
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White,
                                    letterSpacing = 4.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "THE PREMIUM TOURNAMENT PLATFORM",
                                style = TextStyle(
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary,
                                    letterSpacing = 1.sp
                                )
                            )
                        }
                    }
                }
                
                // Overlay text tag
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.Black.copy(alpha = 0.7f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "V5 PREMIUM",
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Welcome Box
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131622)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SportsEsports,
                        contentDescription = "Sports Icon",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                    Column {
                        Text(
                            text = "এউরা টি-২ তে আপনাকে স্বাগতম!",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "আপনার প্রিয় ফ্রি ফায়ার সাধারণ ও ভিলেজ টুর্নামেন্টে অংশ নিন এবং ওয়ালেট রিচার্জ ও রিয়েল আর্নিং উপভোগ করুন।",
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        // ADMIN & APP OWNER VIP PROFILE CARDS
        item {
            Column(modifier = Modifier.padding(top = 4.dp)) {
                Text(
                    text = "👑 আমাদের সম্মানিত পরিচালনা টিম",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Owner Profile Card
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF181510)),
                        border = BorderStroke(1.dp, Color(0xFFFFD700).copy(alpha = 0.3f))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFFD700).copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Stars,
                                    contentDescription = "Owner",
                                    tint = Color(0xFFFFD700),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "MA-SAJEM",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "APP OWNER",
                                color = Color(0xFFFFD700),
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "ডিজাইন ও অপারেশনাল প্রধান",
                                color = Color.Gray,
                                fontSize = 9.sp,
                                textAlign = TextAlign.Center,
                                lineHeight = 12.sp
                            )
                        }
                    }

                    // Admin Profile Card
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF10141E)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = "Admin",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "AMAN ULLAH",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "CHIEF ADMIN",
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "টুর্নামেন্ট রেফারি ও ফাইন্যান্স",
                                color = Color.Gray,
                                fontSize = 9.sp,
                                textAlign = TextAlign.Center,
                                lineHeight = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // NOTICE BOARD SECTION
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📣 অফিশিয়াল ঘোষণা ও নোটিশ বোর্ড",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 15.sp
                )
                
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${notices.size} টি নোটিশ",
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (notices.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "এখনও কোনো নোটিশ পোস্ট করা হয়নি!",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        } else {
            items(notices) { notice ->
                val alreadyVoted = remember(notice.votedUserIds, wallet.playerUid) {
                    val list = notice.votedUserIds.split(",").filter { it.isNotBlank() }
                    wallet.playerUid.isNotBlank() && list.contains(wallet.playerUid)
                }
                
                val totalVotes = notice.likes + notice.dislikes
                val likeRatio = if (totalVotes > 0) notice.likes.toFloat() / totalVotes.toFloat() else 1f
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF111422)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = notice.title,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                val dateFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.US) }
                                val dateStr = remember(notice.timestamp) { dateFormat.format(Date(notice.timestamp)) }
                                Text(
                                    text = "প্রকাশের তারিখ: $dateStr",
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            }
                            
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Notice Icon",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Notice Content Text
                        Text(
                            text = notice.content,
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Simple Voting Visual Status Bar
                        if (totalVotes > 0) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "পছন্দ হয়েছে: ${(likeRatio * 100).toInt()}%",
                                        color = Color(0xFF4CAF50),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "মোট ভোট: $totalVotes টি",
                                        color = Color.Gray,
                                        fontSize = 10.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { likeRatio },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = Color(0xFF4CAF50),
                                    trackColor = Color(0xFFF44336)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                        }

                        // Voting Interaction Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // "পছন্দ হয়েছে" (Like) Button
                            FilledTonalButton(
                                onClick = {
                                    onVoteNotice(notice.id, true, wallet.playerUid)
                                },
                                enabled = !alreadyVoted,
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color(0xFF1B3B2B),
                                    contentColor = Color(0xFF81C784),
                                    disabledContainerColor = Color(0xFF14241B),
                                    disabledContentColor = Color(0xFF4E7751)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ThumbUp,
                                        contentDescription = "Like",
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = "পছন্দ হয়েছে (${notice.likes})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // "পছন্দ হয়নি" (Dislike) Button
                            FilledTonalButton(
                                onClick = {
                                    onVoteNotice(notice.id, false, wallet.playerUid)
                                },
                                enabled = !alreadyVoted,
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color(0xFF3B1F22),
                                    contentColor = Color(0xFFE57373),
                                    disabledContainerColor = Color(0xFF241517),
                                    disabledContentColor = Color(0xFF7A4A4D)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ThumbDown,
                                        contentDescription = "Dislike",
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = "পছন্দ হয়নি (${notice.dislikes})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        if (alreadyVoted) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "✓ আপনি ইতিমধ্যেই আপনার মতামত নিবন্ধন করেছেন",
                                color = Color.Gray,
                                fontSize = 10.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

// ==========================================
// VILLAGE TOURNAMENT TAB (DEPRECATED - MERGED INTO TOURNAMENTS TAB)
// ==========================================
@Composable
fun VillageTournamentTab(
    matches: List<MatchEntity>,
    wallet: UserWalletEntity,
    onJoinMatch: (MatchEntity, String, String?) -> Unit,
    onUpdateProfile: (String, String, String, String, String) -> Unit
) {
    val context = LocalContext.current
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, SOLO, DUO, SQUAD
    var matchToJoin by remember { mutableStateOf<MatchEntity?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Branding Header Panel Styled for Village Cup
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFFFF5722), // Vibrant Village Flame orange
                                MaterialTheme.colorScheme.surface
                            )
                        )
                    )
            ) {
                // High intensity display typography
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "ভিলেজ বনাম সেকশন 🔰",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 24.sp
                    )
                    Text(
                        text = "আপনার ৪ জনের বেস্ট স্কোয়াড নিয়ে নেমে পড়ুন আজকের ম্যাচে!",
                        color = MaterialTheme.colorScheme.secondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // AMAN ULLAH & MA-SAJEM administrative and ownership VIP bar
        item {
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF131622)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Stars, contentDescription = "Owner Icon", tint = Color(0xFFFFD700), modifier = Modifier.size(16.dp))
                            Text("APP OWNER", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 9.sp)
                        }
                        Text("MA-SAJEM", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    }
                    Box(modifier = Modifier.width(1.dp).height(32.dp).background(Color.Gray.copy(alpha = 0.3f)))
                    Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Security, contentDescription = "Admin Icon", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                            Text("CHIEF ADMIN", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                        }
                        Text("AMAN ULLAH", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    }
                }
            }
        }

        // Player Registration card or status
        val isRegistered = wallet.realName.isNotBlank() && wallet.village.isNotBlank()

        if (!isRegistered) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.PersonAdd,
                                contentDescription = "Register",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "প্লেয়ার প্রোফাইল রেজিস্ট্রেশন",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 15.sp
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        Text(
                            text = "টুর্নামেন্টে অংশগ্রহণ করতে প্রথমে আপনার প্লেয়ার আইডি ভেরিফাই এবং সাবমিট করতে হবে।",
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        var realNameInput by remember { mutableStateOf("") }
                        var villageInput by remember { mutableStateOf("") }
                        var playerUidInput by remember { mutableStateOf(wallet.playerUid) }
                        var ignInput by remember { mutableStateOf(wallet.inGameName) }
                        var phoneInput by remember { mutableStateOf(wallet.phone) }

                        OutlinedTextField(
                            value = realNameInput,
                            onValueChange = { realNameInput = it },
                            label = { Text("আপনার আসল পুরো নাম") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        )

                        OutlinedTextField(
                            value = villageInput,
                            onValueChange = { villageInput = it },
                            label = { Text("আপনার গ্রাম / সেকশনের নাম") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        )

                        OutlinedTextField(
                            value = playerUidInput,
                            onValueChange = { playerUidInput = it },
                            label = { Text("ফ্রি ফায়ার প্লেয়ার UID (যেমন: FF52918804)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        )

                        OutlinedTextField(
                            value = ignInput,
                            onValueChange = { ignInput = it },
                            label = { Text("গেমের নাম (In Game Name)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        )

                        OutlinedTextField(
                            value = phoneInput,
                            onValueChange = { phoneInput = it },
                            label = { Text("টাকা উত্তোলনের মোবাইল নম্বর (বিকাশ/নগদ)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        )

                        Button(
                            onClick = {
                                onUpdateProfile(realNameInput, villageInput, playerUidInput, ignInput, phoneInput)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("নিবন্ধিত প্রোফাইল ও সাবমিট করুন 🚀", fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }
            }
        } else {
            // Already registered - render beautiful state
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF101B11)),
                    border = BorderStroke(1.dp, Color(0xFF2E7D32))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Verified Profile", tint = Color(0xFF4CAF50), modifier = Modifier.size(20.dp))
                            Text("প্রোফাইল ভেরিফাইড ও নিবন্ধিত", color = Color(0xFF4CAF50), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("প্লেয়ার: ${wallet.realName}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("গ্রাম: ${wallet.village}", color = Color.LightGray, fontSize = 11.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("UID: ${wallet.playerUid}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("IGN: ${wallet.inGameName}", color = Color.LightGray, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Village vs Section Tournament Guidelines Card (placed right inside this dedicated portal!)
        item {
            var showRules by remember { mutableStateOf(true) }
            val clipboardManager = LocalClipboardManager.current
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF0F121C)
                ),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SportsEsports,
                                contentDescription = "Tournament Portal",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "ভিলেজ টুর্নামেন্ট গাইডলাইনস 🔰",
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                fontSize = 15.sp
                            )
                        }
                        IconButton(
                            onClick = { showRules = !showRules },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = if (showRules) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                contentDescription = "Toggle Rules",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    if (showRules) {
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "🔥 আপনার গ্রামে কি সেরা টিম আছে? তাহলে ভার্সেসে আসুন এবং নিজেকে প্রুভ করুন! 🔥",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                        )

                        Text(
                            text = "এলাকার দাপট এবার গেমের মাঠে! আপনার ৪ জনের বেস্ট স্কোয়াড নিয়ে নেমে পড়ুন \"Village vs Section\" টুর্নামেন্টে। প্রমাণ করে দিন কারা আসল কিং! 👑",
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        )

                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.2f)))
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "📌 স্কোয়াড ম্যাচ রেজিস্ট্রেশনের নিয়মাবলী:",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        // Rule 1
                        Column(modifier = Modifier.padding(bottom = 10.dp)) {
                            Text(
                                text = "১. টিম ও প্লেয়ার নিয়ম:",
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "• এই টুর্নামেন্টটি সম্পূর্ণ ৪ জন ভিত্তিক (Squad Type) ফ্রি ফায়ার ম্যাচ।\n• প্রতিটি টিমে সর্বোচ্চ ৪ জন প্লেয়ার থাকতে পারবে। টিমের নাম নিজেদের ইচ্ছামতো দিতে পারবেন।\n• ৪ জন পূর্ণ হয়ে গেলে ওই টিমে আর কোনো নতুন প্লেয়ার ঢুকতে পারবে না।",
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }

                        // Rule 2
                        Column(modifier = Modifier.padding(bottom = 10.dp)) {
                            Text(
                                text = "২. প্লেয়ার পরিবর্তন (Player Change):",
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "• ম্যাচ শুরু বা রেজিস্ট্রেশন শেষ হওয়ার আগে আপনি আপনার টিমের প্লেয়ার পরিবর্তন করতে পারবেন।\n• নতুন প্লেয়ার নিতে হলে, প্রথমে বর্তমান ৪ জনের মধ্য থেকে যেকোনো একজনকে টিম থেকে বাদ (Remove) দিতে হবে, তারপর নতুন প্লেয়ারকে যুক্ত করতে পারবেন। টিমে একসাথে ৪ জনের বেশি প্লেয়ার রাখা যাবে না।",
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }

                        // Rule 3
                        Column(modifier = Modifier.padding(bottom = 12.dp)) {
                            Text(
                                text = "৩. ম্যাচ সিরিয়াল ও সময়সূচী:",
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "• টুর্নামেন্টের সমস্ত ম্যাচ একটি নির্দিষ্ট সিরিয়াল বা ক্রম অনুযায়ী অনুষ্ঠিত হবে (যেমন: Match #01, Match #02, Match #03)।\n• অ্যাপের স্ক্রিনে ম্যাচের বিবরণ এভাবে দেখতে পাবেন: [ম্যাচ সিরিয়াল] [টিম ১ এর নাম] VS [টিম ২ এর নাম] — [ম্যাচের সময় (BST)]",
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }

                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.2f)))
                        Spacer(modifier = Modifier.height(12.dp))

                        // Share Box
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "🔗 বন্ধুদের সাথে শেয়ার করার জন্য নিচের মেসেজটি কপি করুন:",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )

                                val shareText = """
👋 দোস্ত, তোর ৪ জনের বেস্ট স্কোয়াড রেডি কর! আমাদের গ্রামে কি সেরা টিম আছে? তাহলে ভার্সেসে আয় আর প্রুভ কর! 

নিচের লিংক থেকে এখনই অ্যাপটি নামিয়ে আমাদের "Village vs Section" টুর্নামেন্টে টিম রেজিস্ট্রেশন কর:
👉 https://ais-pre-ykdcd4lsivyfdargv3naot-995191660851.asia-southeast1.run.app
                                """.trimIndent()

                                SelectionContainer {
                                    Text(
                                        text = shareText,
                                        color = Color.LightGray,
                                        fontSize = 11.sp,
                                        lineHeight = 16.sp,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                }

                                Button(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(shareText))
                                        Toast.makeText(context, "মেসেজটি কপি করা হয়েছে! চ্যাট বা মেসেঞ্জারে বন্ধুদের সাথে শেয়ার করুন। 🚀", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    modifier = Modifier.fillMaxWidth().height(38.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copy",
                                        tint = Color.Black,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "মেসেজ কপি করুন 📋",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Black,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Horizontal Category Filter Pills
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val filters = listOf(
                    "ALL" to "সব ম্যাচ",
                    "SOLO" to "সলো (Solo)",
                    "DUO" to "ডুও (Duo)",
                    "SQUAD" to "স্কোয়াড (Squad)"
                )
                filters.forEach { (key, label) ->
                    val isSelected = selectedFilter == key
                    ElevatedAssistChip(
                        onClick = { selectedFilter = key },
                        label = { Text(label, fontWeight = FontWeight.SemiBold) },
                        colors = AssistChipDefaults.elevatedAssistChipColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            labelColor = if (isSelected) Color.White else Color.LightGray
                        ),
                        border = if (isSelected) BorderStroke(1.dp, MaterialTheme.colorScheme.secondary) else null
                    )
                }
            }
        }

        // Filter Matches State
        val filteredMatches = matches.filter {
            selectedFilter == "ALL" || it.type == selectedFilter
        }

        if (filteredMatches.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.SportsEsports,
                            contentDescription = "No Matches Found",
                            tint = Color.Gray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "এই ক্যাটাগরিতে কোনো ভিলেজ ম্যাচ পাওয়া যায়নি!",
                            color = Color.LightGray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(filteredMatches) { match ->
                MatchCard(
                    match = match,
                    wallet = wallet,
                    onJoinClick = { matchToJoin = match }
                )
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }

    // Join Match Confirmation Dialog
    matchToJoin?.let { match ->
        JoinMatchDialog(
            match = match,
            wallet = wallet,
            onDismiss = { matchToJoin = null },
            onConfirmJoin = { ign, squad ->
                onJoinMatch(match, ign, squad)
                matchToJoin = null
            }
        )
    }
}

// Match Card UI layout
@Composable
fun MatchCard(
    match: MatchEntity,
    wallet: UserWalletEntity,
    onJoinClick: () -> Unit
) {
    val isOngoing = match.status == "ONGOING"
    val progress = match.joinedSlots.toFloat() / match.totalSlots.toFloat()
    val isFull = match.joinedSlots >= match.totalSlots

    var isRoomDetailsExpanded by remember { mutableStateOf(false) }

    // We can check if player has already joined this match
    // For demo/simulated safety, we will allow them to check if they have enough balance
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = 1.dp,
            color = if (isOngoing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Title and Type Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = match.title,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 16.sp,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            if (isOngoing) MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)
                            else MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isOngoing) "লাইভ ম্যাচ" else match.type,
                        color = if (isOngoing) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Subtitle info: Map, Date Time
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Map,
                        contentDescription = "Map",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = match.map,
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = "Time",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = match.matchTime,
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Crucial esport info parameters grid
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("মোট প্রাইজ পুল", color = Color.Gray, fontSize = 10.sp)
                    Text(
                        "৳${match.prizePool}",
                        color = MaterialTheme.colorScheme.tertiary,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp
                    )
                }
                Box(
                    modifier = Modifier
                        .height(30.dp)
                        .width(1.dp)
                        .background(Color.Gray.copy(alpha = 0.3f))
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("প্রতি কিল প্রাইজ", color = Color.Gray, fontSize = 10.sp)
                    Text(
                        "৳${match.perKill}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
                Box(
                    modifier = Modifier
                        .height(30.dp)
                        .width(1.dp)
                        .background(Color.Gray.copy(alpha = 0.3f))
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("প্রবেশ ফি (Fee)", color = Color.Gray, fontSize = 10.sp)
                    Text(
                        "৳${match.entryFee}",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Slot Progress Indicator
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "নিবন্ধিত প্লেয়ার: ${match.joinedSlots}/${match.totalSlots}",
                        color = Color.LightGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = if (isFull) "আসন খালি নেই" else "${match.totalSlots - match.joinedSlots}টি আসন খালি",
                        color = if (isFull) Color.Red else MaterialTheme.colorScheme.secondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (isFull) Color.Red else MaterialTheme.colorScheme.primary,
                    trackColor = Color.DarkGray
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Join Action Button Section
            if (isOngoing) {
                Button(
                    onClick = { isRoomDetailsExpanded = !isRoomDetailsExpanded },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.VpnKey, contentDescription = "Room Key")
                        Text(
                            text = "লাইভ ম্যাচ রুম আইডি ও পাসওয়ার্ড দেখুন",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                Button(
                    onClick = onJoinClick,
                    enabled = !isFull,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        disabledContainerColor = Color.DarkGray
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (isFull) "টুর্নামেন্ট ফুল হয়ে গেছে" else "টুর্নামেন্টে জয়েন করুন (৳${match.entryFee})",
                        fontWeight = FontWeight.Bold,
                        color = if (isFull) Color.Gray else Color.White
                    )
                }
            }

            // Expanding Live Room Details
            AnimatedVisibility(
                visible = isRoomDetailsExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = "🎮 ফ্রি ফায়ার কাস্টম রুম ডিটেইলস",
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "রুম আইডি: ${match.roomID ?: "রুম তৈরি হচ্ছে..."}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "পাসওয়ার্ড: ${match.roomPassword ?: "অপেক্ষা করুন..."}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "সতর্কতা: সঠিক সময়ে রুমে জয়েন করুন। রুম আইডি শেয়ার করা নিষেধ!",
                        color = Color.Yellow,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

// Join Form Dialog
@Composable
fun JoinMatchDialog(
    match: MatchEntity,
    wallet: UserWalletEntity,
    onDismiss: () -> Unit,
    onConfirmJoin: (String, String?) -> Unit
) {
    var ign by remember { mutableStateOf(wallet.inGameName) }
    var uid by remember { mutableStateOf(wallet.playerUid) }
    var squadName by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "🏆 টুর্নামেন্ট রেজিস্ট্রেশন",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = match.title,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                // In Game Name Input
                OutlinedTextField(
                    value = ign,
                    onValueChange = { ign = it },
                    label = { Text("ইন-গেম নেম (IGN)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        unfocusedLabelColor = Color.Gray
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Free Fire UID Input
                OutlinedTextField(
                    value = uid,
                    onValueChange = { uid = it },
                    label = { Text("ফ্রি ফায়ার প্লেয়ার UID") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        unfocusedLabelColor = Color.Gray
                    )
                )

                if (match.type == "SQUAD" || match.type == "DUO") {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = squadName,
                        onValueChange = { squadName = it },
                        label = { Text("স্কোয়াড/টিমের নাম (Squad Name)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedLabelColor = MaterialTheme.colorScheme.primary,
                            unfocusedLabelColor = Color.Gray
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Deducting Fee notification
                Text(
                    text = "আপনার অ্যাকাউন্ট থেকে ৳${match.entryFee} কেটে নেওয়া হবে।",
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.LightGray)
                    ) {
                        Text("বাদ দিন")
                    }
                    Button(
                        onClick = {
                            if (ign.isNotBlank() && uid.isNotBlank()) {
                                onConfirmJoin(ign, squadName.takeIf { it.isNotBlank() })
                            }
                        },
                        enabled = ign.isNotBlank() && uid.isNotBlank(),
                        modifier = Modifier.weight(1.5f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("নিশ্চিত করুন")
                    }
                }
            }
        }
    }
}

// ==========================================
// RESULTS TAB (ফলাফল)
// ==========================================
@Composable
fun ResultsTab(completedMatches: List<MatchEntity>) {
    var expandedMatchId by remember { mutableStateOf<Int?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                Text(
                    text = "🏁 টুর্নামেন্টের ফলাফল",
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    fontSize = 20.sp
                )
                Text(
                    text = "সমাপ্ত ম্যাচের স্কোয়াড বিজয়ী এবং কিলার বোর্ড তালিকা দেখুন।",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        }

        if (completedMatches.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 64.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "No results yet",
                            tint = Color.Gray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "কোনো সমাপ্ত ম্যাচের ফলাফল এখনো দেওয়া হয়নি!",
                            color = Color.LightGray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        } else {
            items(completedMatches) { match ->
                val isExpanded = expandedMatchId == match.id
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedMatchId = if (isExpanded) null else match.id },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = match.title,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 15.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.DarkGray)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    match.type,
                                    color = Color.LightGray,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "ম্যাপ: ${match.map} • সফলভাবে সমাপ্ত",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Gold Booyah Winner Banner
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = "Booyah",
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(28.dp)
                            )
                            Column {
                                Text(
                                    text = "🏆 Booyah Winner!",
                                    color = MaterialTheme.colorScheme.tertiary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = match.booyahPlayer ?: "N/A",
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Top Killer Display Info
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = "Top Killer",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "পয়েন্ট টেবিল সেরা কিলার (Most Kills)",
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = match.topKillsPlayer ?: "N/A",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(MaterialTheme.colorScheme.primary)
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "${match.topKillsCount ?: 0} Kills",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isExpanded) "বিস্তারিত ফলাফল বন্ধ করুন" else "কিলবোর্ড ও ফুল লিডারবোর্ড দেখতে ক্লিক করুন",
                                color = MaterialTheme.colorScheme.secondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = "Expand",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.padding(top = 8.dp).size(16.dp)
                            )
                        }

                        // Simulated Esports Player Standings Table
                        AnimatedVisibility(
                            visible = isExpanded,
                            enter = expandVertically() + fadeIn(),
                            exit = shrinkVertically() + fadeOut()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 16.dp)
                            ) {
                                Divider(color = Color.Gray.copy(alpha = 0.3f))
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "📊 পূর্ণ স্কোর ও কিলবোর্ড (Leaderboard)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color.LightGray
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                // Standings Header
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .padding(8.dp)
                                ) {
                                    Text("র‍্যাংক", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.width(40.dp), fontWeight = FontWeight.Bold)
                                    Text("প্লেয়ার/দল IGN", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                                    Text("কিল", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.width(40.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
                                    Text("পুরস্কার", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.width(60.dp), textAlign = TextAlign.End, fontWeight = FontWeight.Bold)
                                }

                                val standings = listOf(
                                    StandingsRow(1, match.booyahPlayer ?: "Winner", match.booyahKills ?: 8, match.prizePool / 2),
                                    StandingsRow(2, match.topKillsPlayer ?: "Top_Gunner", match.topKillsCount ?: 6, match.prizePool / 4),
                                    StandingsRow(3, "X_Dead_Shot", 5, 50),
                                    StandingsRow(4, "Kazi_AURA_09", 4, 30),
                                    StandingsRow(5, "Op_Nabil_VIBE", 3, 15)
                                )

                                standings.forEach { row ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "#${row.rank}",
                                            color = if (row.rank == 1) MaterialTheme.colorScheme.tertiary else Color.LightGray,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            modifier = Modifier.width(40.dp)
                                        )
                                        Text(
                                            text = row.playerIgn,
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text(
                                            text = "${row.kills}",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            modifier = Modifier.width(40.dp),
                                            textAlign = TextAlign.Center
                                        )
                                        Text(
                                            text = "৳${row.prizeEarned}",
                                            color = MaterialTheme.colorScheme.secondary,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 12.sp,
                                            modifier = Modifier.width(60.dp),
                                            textAlign = TextAlign.End
                                        )
                                    }
                                    Divider(color = Color.Gray.copy(alpha = 0.1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

data class StandingsRow(val rank: Int, val playerIgn: String, val kills: Int, val prizeEarned: Int)


// ==========================================
// LEADERBOARD TAB (লিডারবোর্ড তথ্য ও র‍্যাংক)
// ==========================================
data class LeaderboardPlayer(
    val serialNumber: Int,
    val name: String,
    val wins: Int,
    val losses: Int,
    val playerUid: String,
    val phone: String,
    val balance: Double,
    val realName: String = "",
    val village: String = ""
)

@OptIn(ExperimentalAnimationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun LeaderboardTab(wallet: UserWalletEntity) {
    val context = LocalContext.current
    var isTournamentRankSelected by remember { mutableStateOf(true) } // true = Tournament Rank, false = Registration Rank
    var isAdmin by remember { mutableStateOf(false) }
    var showAuthDialog by remember { mutableStateOf(false) }
    var passwordInput by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    
    // Static base sample players
    val samplePlayers = remember {
        listOf(
            LeaderboardPlayer(serialNumber = 1, name = "SHADOW_BOSS", wins = 24, losses = 3, playerUid = "FF9214051B", phone = "01723498124", balance = 550.0, realName = "মো: শাকিল আহমেদ", village = "উত্তরা সেকশন ৪"),
            LeaderboardPlayer(serialNumber = 2, name = "Aura_Rafi_YT", wins = 20, losses = 4, playerUid = "FF39182390", phone = "01855219385", balance = 320.0, realName = "রাফিউর রহমান", village = "কাজীপাড়া"),
            LeaderboardPlayer(serialNumber = 3, name = "Kazi_Squad_Leader", wins = 18, losses = 5, playerUid = "FF83109282", phone = "01933221144", balance = 400.0, realName = "কাজী আসিফ", village = "রামপুরা"),
            LeaderboardPlayer(serialNumber = 4, name = "OP_BOOYAH", wins = 16, losses = 6, playerUid = "FF49830591", phone = "01522883344", balance = 180.0, realName = "মেহেদী হাসান", village = "কালীগঞ্জ গ্রাম"),
            LeaderboardPlayer(serialNumber = 12, name = "Gamer_Rony", wins = 14, losses = 5, playerUid = "FF29184013", phone = "01755663366", balance = 110.0, realName = "রনি আহমেদ", village = "বাসাবো"),
            LeaderboardPlayer(serialNumber = 18, name = "T2_Chucker", wins = 12, losses = 4, playerUid = "FF11029837", phone = "01309874561", balance = 90.0, realName = "চৌধুরী মো: তাসনিম", village = "উত্তরা সেকশন ১০"),
            LeaderboardPlayer(serialNumber = 24, name = "FF_Srabon", wins = 11, losses = 6, playerUid = "FF55610293", phone = "01824123547", balance = 150.0, realName = "শ্রাবণ রহমান", village = "মিরপুর সেকশন ১"),
            LeaderboardPlayer(serialNumber = 37, name = "Section_Hitter", wins = 10, losses = 7, playerUid = "FF36928104", phone = "01928374162", balance = 210.0, realName = "ইনজামামুল হক", village = "খিলগাঁও"),
            LeaderboardPlayer(serialNumber = 42, name = "Village_King", wins = 9, losses = 4, playerUid = "FF82930192", phone = "01736192837", balance = 80.0, realName = "রাজু মোল্লা", village = "কালীগঞ্জ গ্রাম"),
            LeaderboardPlayer(serialNumber = 55, name = "AURA_NABIL", wins = 8, losses = 5, playerUid = "FF91283746", phone = "01567123456", balance = 300.0, realName = "নাবিল চৌধুরী", village = "ধানমন্ডি"),
            LeaderboardPlayer(serialNumber = 102, name = "Noob_Ami", wins = 6, losses = 8, playerUid = "FF09182736", phone = "01323456789", balance = 50.0, realName = "মো: সাব্বির", village = "বনশ্রী"),
            LeaderboardPlayer(serialNumber = 250, name = "Apex_Legend", wins = 5, losses = 3, playerUid = "FF19182731", phone = "01711122233", balance = 130.0, realName = "জাবেদ ইকবাল", village = "উত্তরা সেকশন ১৪"),
            LeaderboardPlayer(serialNumber = 580, name = "Deadly_Storm", wins = 4, losses = 4, playerUid = "FF28193820", phone = "01811223344", balance = 95.0, realName = "ঝড়ো হাওয়া রকি", village = "সাভার"),
            LeaderboardPlayer(serialNumber = 999, name = "Fire_Sniper", wins = 3, losses = 5, playerUid = "FF48192039", phone = "01911223344", balance = 75.0, realName = "নাঈম হোসাইন", village = "টঙ্গী"),
            LeaderboardPlayer(serialNumber = 1212, name = "Bengali_Hero", wins = 2, losses = 6, playerUid = "FF78192048", phone = "01511223344", balance = 40.0, realName = "বীর বাঙালি আকাশ", village = "কেরানীগঞ্জ")
        )
    }

    val currentUserRegistered = wallet.realName.isNotBlank() && wallet.inGameName.isNotBlank()
    
    // Dynamic list construction appending the current profile dynamically
    val allPlayers = remember(wallet, samplePlayers) {
        if (currentUserRegistered) {
            val cleanSamples = samplePlayers.filter { 
                it.name.trim().lowercase(Locale.ROOT) != wallet.inGameName.trim().lowercase(Locale.ROOT) 
            }
            cleanSamples + LeaderboardPlayer(
                serialNumber = 1251, // total registered is 1250, so this user is 1251st
                name = wallet.inGameName,
                wins = 3, // starting wins
                losses = 1, // starting losses
                playerUid = wallet.playerUid,
                phone = wallet.phone,
                balance = wallet.balance,
                realName = wallet.realName,
                village = wallet.village
            )
        } else {
            samplePlayers
        }
    }

    // Helper functions for Bengali locale conversion
    fun toBengaliNumberStr(number: Int): String {
        val englishDigits = number.toString()
        val bengaliDigits = mapOf(
            '0' to '০', '1' to '১', '2' to '২', '3' to '৩', '4' to '৪',
            '5' to '৫', '6' to '৬', '7' to '৭', '8' to '৮', '9' to '৯'
        )
        return englishDigits.map { bengaliDigits[it] ?: it }.joinToString("")
    }

    fun toBengaliDoubleStr(number: Double): String {
        val formatted = String.format(Locale.US, "%.2f", number)
        val bengaliDigits = mapOf(
            '0' to '০', '1' to '১', '2' to '২', '3' to '৩', '4' to '৪',
            '5' to '৫', '6' to '৬', '7' to '৭', '8' to '৮', '9' to '৯',
            '.' to '.'
        )
        return formatted.map { bengaliDigits[it] ?: it }.joinToString("")
    }

    // Compute UI States
    val baseRegisteredCount = if (currentUserRegistered) 1251 else 1250
    val totalRegisteredStr = toBengaliNumberStr(baseRegisteredCount)

    // Sort players based on selection
    val displayedPlayers = remember(allPlayers, isTournamentRankSelected) {
        if (isTournamentRankSelected) {
            // Sort by Wins desc, Losses asc
            allPlayers.sortedWith(
                compareByDescending<LeaderboardPlayer> { it.wins }
                    .thenBy { it.losses }
            )
        } else {
            // Sort by Serial Chronologically ascending
            allPlayers.sortedBy { it.serialNumber }
        }
    }

    var expandedPlayerSerial by remember { mutableStateOf<Int?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Upper Title Header
        item {
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🏆 প্লেয়ার লিডারবোর্ড",
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        fontSize = 20.sp
                    )
                    
                    // Styled Admin View controller button
                    Surface(
                        onClick = {
                            if (isAdmin) {
                                isAdmin = false
                                Toast.makeText(context, "এডমিন মোড নিষ্ক্রিয় হয়েছে। স্পর্শকাতর তথ্য লকড! 🔒", Toast.LENGTH_SHORT).show()
                            } else {
                                showAuthDialog = true
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isAdmin) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, if (isAdmin) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.3f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (isAdmin) Icons.Default.LockOpen else Icons.Default.Lock,
                                contentDescription = "Admin Mode Toggle",
                                tint = if (isAdmin) MaterialTheme.colorScheme.primary else Color.Gray,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = if (isAdmin) "অ্যাডমিন: সক্রিয় 🔓" else "এডমিন লগইন",
                                color = if (isAdmin) MaterialTheme.colorScheme.primary else Color.LightGray,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Text(
                    text = "টুর্নামেন্টের সেরা বিজয়ী এবং নিবন্ধিত গেমারদের তালিকা পর্যালোচনা করুন।",
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }
        }

        // Total Registered Player display Card with animated looks
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF131520)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                    Color.Transparent
                                )
                            )
                        )
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF4CAF50))
                                )
                                Text(
                                    text = "সর্বমোট নিবন্ধিত প্লেয়ার সংখ্যা",
                                    color = Color.LightGray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$totalRegisteredStr জন খেলোয়াড় 👥",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp
                            )
                        }
                        
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = "Trophy icon",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
        }

        // Admin mode warning Banner
        if (isAdmin) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1711)),
                    border = BorderStroke(1.dp, Color(0xFFFF9800).copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Security Status",
                            tint = Color(0xFFFF9800),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "এডমিন অ্যাক্সেস সক্রিয়! প্লেয়ারের স্পর্শকাতর ডাটা (UID, ফোন নম্বর, ব্যালেন্স, ইমেইল) আনলক অবস্থায় আছে। নিচে ক্লিক করে বিস্তারিত দেখুন।",
                            color = Color(0xFFFFD180),
                            fontSize = 10.sp,
                            lineHeight = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Sliding Toggle switch Pills for "Tournament Rank" and "Registration Rank"
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF10121C))
                    .padding(4.dp)
            ) {
                // Tournament rank pill
                Surface(
                    onClick = { isTournamentRankSelected = true },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    color = if (isTournamentRankSelected) MaterialTheme.colorScheme.primary else Color.Transparent
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.padding(vertical = 10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = "Tournaments Rank",
                                tint = if (isTournamentRankSelected) Color.Black else Color.Gray,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "টুর্নামেন্ট র‍্যাংক 🏆",
                                color = if (isTournamentRankSelected) Color.Black else Color.LightGray,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                // Registration rank pill
                Surface(
                    onClick = { isTournamentRankSelected = false },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    color = if (!isTournamentRankSelected) MaterialTheme.colorScheme.primary else Color.Transparent
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.padding(vertical = 10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Leaderboard,
                                contentDescription = "Registration Serial",
                                tint = if (!isTournamentRankSelected) Color.Black else Color.Gray,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "রেজিস্ট্রেশন ক্রমিক 🔢",
                                color = if (!isTournamentRankSelected) Color.Black else Color.LightGray,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Leaderboard Rows
        items(displayedPlayers.size) { index ->
            val player = displayedPlayers[index]
            val isCurrentUser = currentUserRegistered && (player.name.trim().lowercase(Locale.ROOT) == wallet.inGameName.trim().lowercase(Locale.ROOT))
            val isExpanded = expandedPlayerSerial == player.serialNumber

            // Calculate active Rank Index
            val displayRank = index + 1
            
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (isAdmin) {
                            expandedPlayerSerial = if (isExpanded) null else player.serialNumber
                        }
                    },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCurrentUser) Color(0xFF121422) else MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(
                    width = if (isCurrentUser) 1.5.dp else 1.dp,
                    color = when {
                        isCurrentUser -> MaterialTheme.colorScheme.primary
                        displayRank == 1 && isTournamentRankSelected -> Color(0xFFFFD700) // Gold Rank #1
                        displayRank == 2 && isTournamentRankSelected -> Color(0xFFC0C0C0) // Silver Rank #2
                        displayRank == 3 && isTournamentRankSelected -> Color(0xFFCD7F32) // Bronze Rank #3
                        else -> Color.Gray.copy(alpha = 0.1f)
                    }
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Badge & Player details row
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Professional rank indicator bubble
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        when {
                                            isTournamentRankSelected && displayRank == 1 -> Color(0xFFFFD700).copy(alpha = 0.2f)
                                            isTournamentRankSelected && displayRank == 2 -> Color(0xFFC0C0C0).copy(alpha = 0.2f)
                                            isTournamentRankSelected && displayRank == 3 -> Color(0xFFCD7F32).copy(alpha = 0.2f)
                                            else -> MaterialTheme.colorScheme.surfaceVariant
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (isTournamentRankSelected) {
                                        when (displayRank) {
                                            1 -> "🥇"
                                            2 -> "🥈"
                                            3 -> "🥉"
                                            else -> toBengaliNumberStr(displayRank)
                                        }
                                    } else {
                                        "#${toBengaliNumberStr(player.serialNumber)}"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = when {
                                        isTournamentRankSelected && displayRank == 1 -> Color(0xFFFFD700)
                                        isTournamentRankSelected && displayRank == 2 -> Color(0xFFC0C0C0)
                                        isTournamentRankSelected && displayRank == 3 -> Color(0xFFCD7F32)
                                        else -> Color.LightGray
                                    }
                                )
                            }

                            // Name column
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = player.name,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isCurrentUser) MaterialTheme.colorScheme.primary else Color.White,
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    
                                    if (isCurrentUser) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = "আপনি",
                                                color = MaterialTheme.colorScheme.primary,
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                                
                                // Display rank type detail tag below name
                                Text(
                                    text = if (isTournamentRankSelected) {
                                        "রেজিস্ট্রেশন সিরিয়াল: #${toBengaliNumberStr(player.serialNumber)}"
                                    } else {
                                        "টুর্নামেন্ট র‍্যাংক: #${toBengaliNumberStr(displayRank)}"
                                    },
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        // Win/Loss display panel (PUBLIC SAFE DATA)
                        Column(horizontalAlignment = Alignment.End) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF2E7D32).copy(alpha = 0.15f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${toBengaliNumberStr(player.wins)} জয়",
                                        color = Color(0xFF4CAF50),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFFC62828).copy(alpha = 0.15f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${toBengaliNumberStr(player.losses)} হার",
                                        color = Color(0xFFEF5350),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                            
                            // Win percentage rate calculation
                            val totalPlayed = player.wins + player.losses
                            val winRate = if (totalPlayed > 0) {
                                (player.wins.toDouble() / totalPlayed.toDouble() * 100.0).toInt()
                            } else 0
                            
                            Text(
                                text = "উইন রেট: ${toBengaliNumberStr(winRate)}%",
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }

                    // Strict admin details view (Only shown when verified as an admin)
                    if (isAdmin && isExpanded) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(Color.Gray.copy(alpha = 0.15f))
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        Text(
                            text = "🔐 গেমার সিক্রেট তথ্য (অ্যাডমিন ভিউ)",
                            color = Color(0xFFFF9800),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        
                        Column(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black.copy(alpha = 0.2f))
                                .padding(8.dp)
                        ) {
                            // Real Name
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("আসল পুরো নাম:", color = Color.Gray, fontSize = 10.sp)
                                Text(
                                    text = if (player.realName.isNotBlank()) player.realName else "উল্লেখ নেই",
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.sp
                                )
                            }
                            // Area / Village
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("গ্রাম / সেকশন:", color = Color.Gray, fontSize = 10.sp)
                                Text(
                                    text = if (player.village.isNotBlank()) player.village else "উল্লেখ নেই",
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.sp
                                )
                            }
                            // Free Fire UID
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("ফ্রি ফায়ার UID:", color = Color.Gray, fontSize = 10.sp)
                                SelectionContainer {
                                    Text(
                                        text = player.playerUid,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                            // Phone Number
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("মোবাইল নম্বর:", color = Color.Gray, fontSize = 10.sp)
                                SelectionContainer {
                                    Text(
                                        text = if (player.phone.isNotBlank()) player.phone else "উল্লেখ নেই",
                                        color = Color.LightGray,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                            // Balance
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("ওয়ালেট ব্যালেন্স:", color = Color.Gray, fontSize = 10.sp)
                                Text(
                                    text = "৳ ${toBengaliDoubleStr(player.balance)}",
                                    color = Color(0xFF4CAF50),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    } else if (isAdmin) {
                        // Small hint to click card and expand
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "💡 যেকোনো প্লেয়ারের স্পর্শকাতর ডাটা দেখতে এই কার্ডে ক্লিক করুন।",
                            color = Color.Gray.copy(alpha = 0.8f),
                            fontSize = 8.sp,
                            modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 4.dp)
                        )
                    }
                }
            }
        }
        
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }

    // Modal dialog screen for authentication check
    if (showAuthDialog) {
        Dialog(onDismissRequest = { showAuthDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Security lock",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "এডমিন অথেনটিকেশন 🔐",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "লিডারবোর্ডের খেলোয়াড়দের সকল গোপনীয় ডাটা পর্যালোচনা ও পরিচালনার জন্য অনুগ্রহ করে সিক্রেট কোড প্রবেশ করান।",
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        color = Color.LightGray,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("মাস্টার সিক্রেট কী (পাসওয়ার্ড)", fontSize = 11.sp) },
                        singleLine = true,
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Toggle password visibility",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                passwordInput = ""
                                showAuthDialog = false
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("বাতিল", fontWeight = FontWeight.Bold)
                        }
                        
                        Button(
                            onClick = {
                                if (passwordInput.trim() == "AURA999") {
                                    isAdmin = true
                                    showAuthDialog = false
                                    passwordInput = ""
                                    Toast.makeText(context, "এডমিন মোড সফলভাবে সক্রিয় হয়েছে! 🔓", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "ভুল পাসওয়ার্ড! আবার চেষ্টা করুন।", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("অথোরাইজ", fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// WALLET & PROFILE TAB (ওয়ালেট ও প্রোফাইল)
// ==========================================
@Composable
fun WalletTab(
    wallet: UserWalletEntity,
    transactions: List<TransactionEntity>,
    onUpdateProfile: (String, String, String, String, String) -> Unit,
    onDeposit: (Double, String, String, String) -> Unit,
    onWithdraw: (Double, String, String) -> Unit
) {
    val context = LocalContext.current
    var showProfileDialog by remember { mutableStateOf(false) }
    var showDepositDialog by remember { mutableStateOf(false) }
    var showWithdrawDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcoming & Profile header
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Profile gaming icon
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primary,
                                        MaterialTheme.colorScheme.surfaceVariant
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SportsEsports,
                            contentDescription = "User Avatar",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = wallet.inGameName.ifBlank { "প্লেয়ার সেটআপ করুন!" },
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "UID: ${wallet.playerUid.ifBlank { "N/A" }}",
                            color = MaterialTheme.colorScheme.secondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "মোবাইল: ${wallet.phone.ifBlank { "N/A" }}",
                            color = Color.LightGray,
                            fontSize = 11.sp
                        )
                    }

                    IconButton(
                        onClick = { showProfileDialog = true },
                        modifier = Modifier.testTag("edit_profile_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Profile",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        // Wallet Balance & Deposit Actions
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "আপনার মোট ওয়ালেট ব্যালেন্স", color = Color.Gray, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "৳ ${String.format(Locale.US, "%.2f", wallet.balance)}",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 32.sp
                    )
                    Text(
                        text = "৳১০০ = ১০০ কয়েন (খেলার টিকিট)",
                        color = MaterialTheme.colorScheme.secondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { showDepositDialog = true },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.AddCard, contentDescription = "Deposit")
                                Text("টাকা জমা করুন", fontWeight = FontWeight.Bold)
                            }
                        }

                        OutlinedButton(
                            onClick = { showWithdrawDialog = true },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                            border = BorderStroke(1.dp, Color.White),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.CallReceived, contentDescription = "Withdraw")
                                Text("টাকা তুলুন", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Transaction History List Header
        item {
            Text(
                text = "সাম্প্রতিক লেনদেনের বিবরণ",
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontSize = 15.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (transactions.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "কোনো লেনদেন পাওয়া যায়নি!",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        } else {
            items(transactions) { txn ->
                val formatter = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
                val dateString = formatter.format(Date(txn.timestamp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        when (txn.type) {
                                            "DEPOSIT" -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)
                                            "WITHDRAW" -> MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                            else -> Color.DarkGray
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (txn.type) {
                                        "DEPOSIT" -> Icons.Default.TrendingUp
                                        "WITHDRAW" -> Icons.Default.TrendingDown
                                        else -> Icons.Default.LocalPlay
                                    },
                                    contentDescription = "Transaction Type",
                                    tint = when (txn.type) {
                                        "DEPOSIT" -> MaterialTheme.colorScheme.secondary
                                        "WITHDRAW" -> MaterialTheme.colorScheme.primary
                                        else -> Color.White
                                    },
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = when (txn.type) {
                                        "DEPOSIT" -> "টাকা ডিপোজিট (${txn.method})"
                                        "WITHDRAW" -> "টাকা উত্তোলন (${txn.method})"
                                        else -> "টুর্নামেন্ট ফি কাটা"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "TXID: ${txn.transactionId}",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = dateString,
                                    color = Color.Gray,
                                    fontSize = 9.sp
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = when (txn.type) {
                                    "DEPOSIT" -> "+৳${txn.amount}"
                                    else -> "-৳${txn.amount}"
                                },
                                fontWeight = FontWeight.Black,
                                color = when (txn.type) {
                                    "DEPOSIT" -> MaterialTheme.colorScheme.secondary
                                    else -> MaterialTheme.colorScheme.primary
                                },
                                fontSize = 14.sp
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        when (txn.status) {
                                            "SUCCESS" -> Color(0xFF00E676).copy(alpha = 0.2f)
                                            "PENDING" -> Color(0xFFFFD600).copy(alpha = 0.2f)
                                            else -> Color.Red.copy(alpha = 0.2f)
                                        }
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = when (txn.status) {
                                        "SUCCESS" -> "সফল"
                                        "PENDING" -> "চলমান"
                                        else -> "প্রত্যাখ্যাত"
                                    },
                                    color = when (txn.status) {
                                        "SUCCESS" -> Color(0xFF00E676)
                                        "PENDING" -> Color(0xFFFFD600)
                                        else -> Color.Red
                                    },
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }

    // Edit Profile Sheet/Dialog
    if (showProfileDialog) {
        var tempRealName by remember { mutableStateOf(wallet.realName) }
        var tempVillage by remember { mutableStateOf(wallet.village) }
        var tempIgn by remember { mutableStateOf(wallet.inGameName) }
        var tempUid by remember { mutableStateOf(wallet.playerUid) }
        var tempPhone by remember { mutableStateOf(wallet.phone) }

        Dialog(onDismissRequest = { showProfileDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "⚙️ খেলোয়াড় তথ্য আপডেট",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = tempRealName,
                        onValueChange = { tempRealName = it },
                        label = { Text("খেলোয়াড়ের আসল নাম") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = tempVillage,
                        onValueChange = { tempVillage = it },
                        label = { Text("গ্রাম বা এলাকার নাম ও সেকশন") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = tempIgn,
                        onValueChange = { tempIgn = it },
                        label = { Text("ইন-গেম নেম (IGN)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = tempUid,
                        onValueChange = { tempUid = it },
                        label = { Text("ফ্রি ফায়ার প্লেয়ার ID") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = tempPhone,
                        onValueChange = { tempPhone = it },
                        label = { Text("যোগাযোগ নম্বর") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = { showProfileDialog = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("বাতিল")
                        }
                        Button(
                            onClick = {
                                onUpdateProfile(tempRealName, tempVillage, tempUid, tempIgn, tempPhone)
                                showProfileDialog = false
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("সংরক্ষণ")
                        }
                    }
                }
            }
        }
    }

    // Deposit Money Dialog
    if (showDepositDialog) {
        var selectedMethod by remember { mutableStateOf("bKash") }
        var depositAmount by remember { mutableStateOf("") }
        var senderNum by remember { mutableStateOf(wallet.phone) }
        var trxId by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showDepositDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .verticalScroll(rememberScrollState()),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "📥 টুর্নামেন্ট ওয়ালেট রিচার্জ",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Gateway channels row selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("bKash", "Nagad", "Rocket").forEach { method ->
                            val isSelected = selectedMethod == method
                            Surface(
                                onClick = { selectedMethod = method },
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(
                                    width = 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Transparent
                            ) {
                                Text(
                                    text = method,
                                    modifier = Modifier.padding(vertical = 12.dp),
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.LightGray,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Payment details
                    val clipboardManager = LocalClipboardManager.current
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "💡 পেমেন্ট নিয়মাবলী:",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "আমাদের $selectedMethod পার্সোনাল নম্বরে প্রথমে 'Send Money' করুন। তারপর নিচে আপনার প্রেরক নম্বর এবং রিসিভড লেনদেন ID দিন।",
                            color = Color.LightGray,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("$selectedMethod পার্সোনাল নম্বর:", color = Color.Gray, fontSize = 9.sp)
                                Text("01707320129", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            IconButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString("01707320129"))
                                    Toast.makeText(context, "নম্বরটি কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy number",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = depositAmount,
                        onValueChange = { depositAmount = it },
                        label = { Text("টাকার পরিমাণ (BDT)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = senderNum,
                        onValueChange = { senderNum = it },
                        label = { Text("যে নম্বর থেকে টাকা পাঠিয়েছেন") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = trxId,
                        onValueChange = { trxId = it },
                        label = { Text("ট্রানজেকশন ID (TrxID)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = { showDepositDialog = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("বাতিল")
                        }
                        Button(
                            onClick = {
                                val amt = depositAmount.toDoubleOrNull() ?: 0.0
                                onDeposit(amt, selectedMethod, senderNum, trxId)
                                showDepositDialog = false
                            },
                            enabled = depositAmount.isNotBlank() && senderNum.isNotBlank() && trxId.isNotBlank(),
                            modifier = Modifier.weight(1.5f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("ভেরিফাই পেমেন্ট")
                        }
                    }
                }
            }
        }
    }

    // Withdraw Money Dialog
    if (showWithdrawDialog) {
        var selectedMethod by remember { mutableStateOf("bKash") }
        var withdrawAmount by remember { mutableStateOf("") }
        var receiverNum by remember { mutableStateOf(wallet.phone) }

        Dialog(onDismissRequest = { showWithdrawDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "📤 টাকা উত্তোলন (Withdraw)",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("bKash", "Nagad", "Rocket").forEach { method ->
                            val isSelected = selectedMethod == method
                            Surface(
                                onClick = { selectedMethod = method },
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(
                                    width = 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Transparent
                            ) {
                                Text(
                                    text = method,
                                    modifier = Modifier.padding(vertical = 12.dp),
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.LightGray,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = withdrawAmount,
                        onValueChange = { withdrawAmount = it },
                        label = { Text("উত্তোলনের পরিমাণ (৳)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = receiverNum,
                        onValueChange = { receiverNum = it },
                        label = { Text("টাকা পাওয়ার নম্বর (Personal)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "নোট: টাকা উত্তোলন সম্পন্ন হতে ১২-২৪ ঘণ্টা সময় লাগতে পারে।",
                        color = Color.Yellow,
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = { showWithdrawDialog = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("বাতিল")
                        }
                        Button(
                            onClick = {
                                val amt = withdrawAmount.toDoubleOrNull() ?: 0.0
                                onWithdraw(amt, selectedMethod, receiverNum)
                                showWithdrawDialog = false
                            },
                            enabled = withdrawAmount.isNotBlank() && receiverNum.isNotBlank(),
                            modifier = Modifier.weight(1.5f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("উত্তোলন করুন")
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// RULES & SUPPORT TAB (সহায়তা ও নিয়মাবলী)
// ==========================================
@Composable
fun RulesSupportTab() {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var inputQuery by remember { mutableStateOf("") }
    val chatMessages = remember {
        mutableStateListOf(
            ChatMessage("আসসালামু আলাইকুম! AURA T2 তে স্বাগতম। আপনার যেকোনো সমস্যায় সাহায্য করতে আমরা ইচ্ছুক। নিচে বার্তা লিখুন!", false)
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                Text(
                    text = "🛡️ খেলা ও ব্যবহারের নিয়মাবলী",
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    fontSize = 20.sp
                )
                Text(
                    text = "টুর্নামেন্ট সুষ্ঠুভাবে পরিচালনা করতে সকল নিয়ম মেনে চলুন।",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        }

        // Rules Accordion List
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val rulesList = listOf(
                        "১. হ্যাকিং ও নিষিদ্ধ টুলস" to "কোনো রকম হ্যাক অথবা থার্ড পার্টি ইন্টারফেস টুলস ব্যবহার করা কঠোরভাবে নিষিদ্ধ। ধরা পড়লে আপনার অ্যাকাউন্ট স্থায়ীভাবে নিষিদ্ধ করা হবে এবং ব্যালেন্স ফেরত দেওয়া হবে না।",
                        "২. ইমুলেটর সংক্রান্ত নিয়ম" to "সমস্ত টুর্নামেন্ট শুধুমাত্র মোবাইল প্লেয়ারদের জন্য প্রযোজ্য। কোনো রকম ইমুলেটর ব্যবহারকারী ম্যাচে অংশ নিতে পারবেন না।",
                        "৩. রুম আইডি ও পাসওয়ার্ড" to "ম্যাচ শুরু হওয়ার ঠিক ১৫ মিনিট আগে সংশ্লিষ্ট টুর্নামেন্টের কার্ডে (টুর্নামেন্ট ট্যাবে) লাইভ রুম আইডি এবং পাসওয়ার্ড দেওয়া হবে। গেমে প্রবেশ করা সম্পূর্ণভাবে প্লেয়ারের নিজস্ব দায়িত্ব।",
                        "৪. রেজাল্ট এবং পুরস্কার বিতরণ" to "ম্যাচ শেষ হওয়ার ৩০ মিনিটের মধ্যে গিল ও বুইয়ার উপর ভিত্তি করে অটোমেটিকভাবে আপনার ব্যালেন্স অ্যাকাউন্টে টাকা যোগ হয়ে যাবে।"
                    )
                    rulesList.forEach { (heading, desc) ->
                        Column(modifier = Modifier.padding(vertical = 6.dp)) {
                            Text(text = heading, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = desc, color = Color.LightGray, fontSize = 11.sp, lineHeight = 16.sp)
                        }
                        Divider(color = Color.Gray.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 6.dp))
                    }
                }
            }
        }

        // Support Hotlines Buttons
        item {
            Text(
                text = "📞 আমাদের অফিশিয়াল সাপোর্ট হটলাইন",
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontSize = 15.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    onClick = { Toast.makeText(context, "টেলিগ্রাম গ্রুপ জয়েন সম্পন্ন!", Toast.LENGTH_SHORT).show() },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Telegram", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Telegram", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                    }
                }

                Surface(
                    onClick = {
                        clipboardManager.setText(AnnotatedString("01707320129"))
                        Toast.makeText(context, "হেল্পলাইন নম্বর 01707320129 কপি হয়েছে!", Toast.LENGTH_SHORT).show()
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=8801707320129"))
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "হোয়াটসঅ্যাপে মেসেজ পাঠান: 01707320129", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "Call Support", tint = AccentGreen, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("WhatsApp Helpline", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 11.sp)
                    }
                }
            }
        }

        // Live Chat Simulation Box
        item {
            Text(
                text = "💬 ইনস্ট্যান্ট কোয়েশ্চেন ও লাইভ চ্যাট",
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontSize = 15.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Chat message scrolling log wrapper
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 8.dp)
                        ) {
                            chatMessages.forEach { chatMsg ->
                                AlignChatMessage(msg = chatMsg)
                            }
                        }
                    }

                    // Chat input and send button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = inputQuery,
                            onValueChange = { inputQuery = it },
                            placeholder = { Text("আপনার প্রশ্ন এখানে লিখুন...", fontSize = 12.sp, color = Color.Gray) },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            textStyle = TextStyle(fontSize = 13.sp)
                        )

                        IconButton(
                            onClick = {
                                if (inputQuery.isNotBlank()) {
                                    val queryText = inputQuery
                                    chatMessages.add(ChatMessage(queryText, true))
                                    inputQuery = ""

                                    // Auto simulated professional support response
                                    val reply = generateLiveSupportReply(queryText)
                                    chatMessages.add(ChatMessage(reply, false))
                                }
                            },
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

data class ChatMessage(val content: String, val isMe: Boolean)

@Composable
fun AlignChatMessage(msg: ChatMessage) {
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (msg.isMe) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 10.dp,
                topEnd = 10.dp,
                bottomStart = if (msg.isMe) 10.dp else 0.dp,
                bottomEnd = if (msg.isMe) 0.dp else 10.dp
            ),
            color = if (msg.isMe) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 240.dp)
        ) {
            Text(
                text = msg.content,
                color = Color.White,
                fontSize = 12.sp,
                modifier = Modifier.padding(10.dp),
                lineHeight = 16.sp
            )
        }
    }
}

fun generateLiveSupportReply(query: String): String {
    val q = query.lowercase()
    return when {
        q.contains("টাকা") || q.contains("ডিপোজিট") || q.contains("deposit") || q.contains("ব্যালেন্স") -> {
            "আপনার প্রেরিত ডিপোজিট লেনদেন সাথে সাথেই প্রোফাইলের খতিয়ানে যাচাই করে ওয়াлеটে যোগ হয়ে যাবে। কোনো কারণে না হলে হটলাইনে মেসেজ দিন।"
        }
        q.contains("উত্তোলন") || q.contains("withdraw") || q.contains("টাকা তুল") -> {
            "টাকা উত্তোলনের আবেদন জমা দেওয়ার পর ১২ ঘণ্টার মধ্যে আপনার বিকাশ বা নগদ নম্বরে পৌঁছে যাবে। দয়া করে ধৈর্য ধরুন!"
        }
        q.contains("রুম আইডি") || q.contains("রুম") || q.contains("পাসওয়ার্ড") || q.contains("room") -> {
            "টুর্নামেন্ট শুরু হওয়ার ১৫ মিনিট আগে এই অ্যাপের ম্যাচ কার্ডের ভিতরে 'লাইভ ম্যাচ রুম আইডি ও পাসওয়ার্ড' বাটন ক্লিক করে আইডি পেয়ে যাবেন।"
        }
        q.contains("হ্যাক") || q.contains("নিয়ম") -> {
            "AURA T2 তে হ্যাকিং সর্বাত্মক নিষিদ্ধ। ধরা পড়লে অ্যাকাউন্ট স্থায়ীভাবে ব্লক হবে।"
        }
        else -> {
            "আমরা আপনার বার্তা পেয়েছি! আমাদের অ্যাডমিন প্যানেল খুব দ্রুত আপনার তথ্য পরীক্ষা করছে। যেকোনো টিকিট ও লাইভ সাপোর্ট পেতে টেলিগ্রাম গ্রুপে যুক্ত হোন।"
        }
    }
}

@Composable
fun AdminTab(
    wallet: UserWalletEntity,
    matches: List<MatchEntity>,
    transactions: List<TransactionEntity>,
    leaderboardPlayers: List<LeaderboardPlayerEntity>,
    notices: List<com.example.data.NoticeEntity>,
    onApproveTransaction: (Int) -> Unit,
    onRejectTransaction: (Int) -> Unit,
    onAddTournament: (MatchEntity) -> Unit,
    onGiveTrialBalance: (Double) -> Unit,
    onUpdateLeaderboardPlayer: (LeaderboardPlayerEntity) -> Unit,
    onAddNotice: (String, String) -> Unit,
    onDeleteNotice: (Int) -> Unit
) {
    val context = LocalContext.current
    var adminCode by remember { mutableStateOf("") }
    var isUnlocked by remember { mutableStateOf(false) }

    if (!isUnlocked) {
        // Locked Screen
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Locked",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "অ্যাডমিন পোর্টাল লকড",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        fontSize = 20.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "এই পোর্টালটি শুধুমাত্র প্রধান এডমিনদের জন্য সুরক্ষিত। অনুমতি ছাড়া প্রবেশ সম্পূর্ণ নিষিদ্ধ।",
                        color = Color.LightGray,
                        textAlign = TextAlign.Center,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    var isPasswordVisible by remember { mutableStateOf(false) }
                    OutlinedTextField(
                        value = adminCode,
                        onValueChange = { adminCode = it },
                        label = { Text("এডমিন মাস্টার পাসওয়ার্ড") },
                        singleLine = true,
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = if (isPasswordVisible) "Hide password" else "Show password",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = {
                            if (adminCode.trim() == "AURA999") {
                                isUnlocked = true
                            } else {
                                Toast.makeText(context, "ভুল পাসওয়ার্ড! সঠিক কোডটি লিখুন।", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("পোর্টাল আনলক করুন", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    } else {
        // Unlocked Admin Dashboard (5 Sub-tabs)
        var adminSubTab by remember { mutableStateOf(0) } // 0: Txns, 1: Add Match, 2: Player List, 3: Results Inputting, 4: Accounts Finance
        var editingPlayerToUpdate by remember { mutableStateOf<LeaderboardPlayerEntity?>(null) }

        val totalDepositsMoney = remember(transactions) {
            transactions.filter { it.type == "DEPOSIT" && it.status == "SUCCESS" }.sumOf { it.amount }
        }
        val totalWithdrawnMoney = remember(transactions) {
            transactions.filter { it.type == "WITHDRAW" && it.status == "SUCCESS" }.sumOf { it.amount }
        }
        val trialAdditions = remember(transactions) {
            transactions.filter { it.method == "Trial Balance" }.sumOf { it.amount }
        }
        val totalTicketSold = remember(matches) {
            matches.sumOf { it.joinedSlots * it.entryFee }.toDouble()
        }
        val totalPrizesDistributed = remember(matches) {
            matches.filter { it.status == "COMPLETED" }.sumOf { it.prizePool }.toDouble()
        }
        val appCorporateEarnings = totalTicketSold - totalPrizesDistributed

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                    Text(
                        text = "⚡ কাস্টমাইজড কন্ট্রোল প্যানেল (AURA HQ)",
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        fontSize = 20.sp
                    )
                    Text(
                        text = "সহজেই টুর্নামেন্ট নির্ধারণ করুন, মেম্বার ডাটাবেস হ্যান্ডেল করুন এবং সম্পূর্ণ আর্থিক লেনদেন ট্র্যাক করুন।",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
            }

            // Scrollable Tab Selectors
            item {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF151829))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val tabTitles = listOf("লেনদেন অনুমোদন 💳", "টুর্নামেন্ট ক্রিয়েটর 🎮", "ইউজার তালিকা 👥", "ফলাফল এন্ট্রি 🏆", "অ্যাকাউন্টস হিসাব 📊", "ঘোষণা ও নোটিশ 📣")
                    items(tabTitles.size) { index ->
                        val isSelected = adminSubTab == index
                        Surface(
                            onClick = { adminSubTab = index },
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent
                        ) {
                            Text(
                                text = tabTitles[index],
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.Black else Color.LightGray,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            if (adminSubTab == 0) {
                // 1. Transactions Approval Tab
                val pendingTxns = transactions.filter { it.status == "PENDING" }
                if (pendingTxns.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("অনুমোদনের জন্য কোনো লেনদেন (PENDING) পেন্ডিং নেই!", color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    items(pendingTxns) { txn ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(
                                                if (txn.type == "DEPOSIT") MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)
                                                else MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = if (txn.type == "DEPOSIT") "ডিপোজিট আবেদন" else "উত্তোলন আবেদন",
                                            color = if (txn.type == "DEPOSIT") MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                    }

                                    Text(
                                        text = "৳ ${txn.amount}",
                                        fontWeight = FontWeight.Black,
                                        color = Color.White,
                                        fontSize = 16.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("পদ্ধতি: ${txn.method}", color = Color.LightGray, fontSize = 11.sp)
                                        Text("অ্যাকাউন্ট: ${txn.accountNo}", color = Color.LightGray, fontSize = 11.sp)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("TrxID: ${txn.transactionId}", color = Color.Yellow, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { onApproveTransaction(txn.id) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("অনুমোদন দিন", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }

                                    OutlinedButton(
                                        onClick = { onRejectTransaction(txn.id) },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                                        border = BorderStroke(1.dp, Color.Red),
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("বাতিল করুন", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (adminSubTab == 1) {
                // 2. Add Tournament creator
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        var title by remember { mutableStateOf("") }
                        var mapType by remember { mutableStateOf("BERMUDA") }
                        var modeType by remember { mutableStateOf("SOLO") }
                        var isFree by remember { mutableStateOf(false) }
                        var entryFee by remember { mutableStateOf("২০") }
                        var prizePool by remember { mutableStateOf("৫০০") }
                        var perKill by remember { mutableStateOf("৫") }
                        var dateTime by remember { mutableStateOf("১৫ জুন, রাত ০৯:০০ টা") }
                        var totalSlots by remember { mutableStateOf("৪৮") }
                        var isVillageMatch by remember { mutableStateOf(false) }
                        var customizedRules by remember { mutableStateOf("") }

                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("প্রফেশনাল টুর্নামেন্ট ক্রিয়েটর পোর্টাল", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)

                            OutlinedTextField(
                                value = title,
                                onValueChange = { title = it },
                                label = { Text("টুর্নামেন্ট টাইটেল (যেমন: AURA T2 - সলো কিং)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Free / Paid Toggle Selector
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("টুর্নামেন্ট টাইপ:", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.width(110.dp))
                                Row(
                                    modifier = Modifier.weight(1f),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(
                                        onClick = {
                                            isFree = false
                                            if (entryFee == "০") entryFee = "২০"
                                        },
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (!isFree) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.DarkGray,
                                        border = BorderStroke(1.dp, if (!isFree) MaterialTheme.colorScheme.primary else Color.Transparent)
                                    ) {
                                        Text("পেইড টুর্নামেন্ট (Paid)", modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Surface(
                                        onClick = {
                                            isFree = true
                                            entryFee = "০" // lock at 0 BDT
                                        },
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isFree) MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f) else Color.DarkGray,
                                        border = BorderStroke(1.dp, if (isFree) MaterialTheme.colorScheme.secondary else Color.Transparent)
                                    ) {
                                        Text("ফ্রি টুর্নামেন্ট (Free)", modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = mapType,
                                    onValueChange = { mapType = it },
                                    label = { Text("ম্যাপ (BERMUDA, etc.)") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )

                                OutlinedTextField(
                                    value = modeType,
                                    onValueChange = { modeType = it },
                                    label = { Text("মোড (SOLO / SQUAD)") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = entryFee,
                                    onValueChange = { if (!isFree) entryFee = it },
                                    label = { Text(if (isFree) "এন্ট্রি ফি (লকড)" else "এন্ট্রি ফি (৳)") },
                                    singleLine = true,
                                    enabled = !isFree, // dynamically disable based on type
                                    modifier = Modifier.weight(1f)
                                )

                                OutlinedTextField(
                                    value = prizePool,
                                    onValueChange = { prizePool = it },
                                    label = { Text("মোট প্রাইজ পুল (৳)") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = perKill,
                                    onValueChange = { perKill = it },
                                    label = { Text("পার কিল বোনাস (৳)") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )

                                OutlinedTextField(
                                    value = totalSlots,
                                    onValueChange = { totalSlots = it },
                                    label = { Text("সর্বমোট টিকিট স্লট") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            OutlinedTextField(
                                value = dateTime,
                                onValueChange = { dateTime = it },
                                label = { Text("খেলা শুরুর সময় (বাংলা)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = customizedRules,
                                onValueChange = { customizedRules = it },
                                label = { Text("ম্যাচের কাস্টম নিয়মাবলী এবং স্পেশাল পলিসি") },
                                minLines = 2,
                                maxLines = 5,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isVillageMatch,
                                    onCheckedChange = { isVillageMatch = it },
                                    colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                                )
                                Text("এটি একটি 'গ্রাম বনাম সেকশন' (Village vs Section) ম্যাচ", color = Color.White, fontSize = 12.sp)
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = {
                                    if (title.isNotBlank()) {
                                        val entry = if (isFree) 0 else entryFee.replace("১","1").replace("২","2").replace("৩","3").replace("৪","4").replace("৫","5").replace("৬","6").replace("৭","7").replace("৮","8").replace("৯","9").replace("০","0").toIntOrNull() ?: 0
                                        val prize = prizePool.replace("১","1").replace("২","2").replace("৩","3").replace("৪","4").replace("৫","5").replace("৬","6").replace("৭","7").replace("৮","8").replace("৯","9").replace("০","0").toIntOrNull() ?: 0
                                        val pk = perKill.replace("১","1").replace("২","2").replace("৩","3").replace("৪","4").replace("৫","5").replace("৬","6").replace("৭","7").replace("৮","8").replace("৯","9").replace("০","0").toIntOrNull() ?: 0
                                        val slots = totalSlots.toIntOrNull() ?: 48

                                        val match = MatchEntity(
                                            title = title,
                                            map = mapType,
                                            type = modeType,
                                            entryFee = entry,
                                            prizePool = prize,
                                            perKill = pk,
                                            matchTime = dateTime,
                                            totalSlots = slots,
                                            joinedSlots = 0,
                                            status = "UPCOMING",
                                            roomID = "N/A",
                                            roomPassword = "N/A",
                                            isVillageMatch = isVillageMatch,
                                            rules = customizedRules.ifBlank { "১. এমুলেটর সম্পূর্ণ নিষিদ্ধ।\n২. সঠিক সময়ে রুমে উপস্থিত হন।" },
                                            isFree = isFree
                                        )
                                        onAddTournament(match)
                                        title = ""
                                        customizedRules = ""
                                    }
                                },
                                enabled = title.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("টুর্নামেন্ট পাবলিশ করুন", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else if (adminSubTab == 2) {
                // 3. User Listing Directory Panel
                if (leaderboardPlayers.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("কোনো নিবন্ধিত প্লেয়ার পাওয়া গাড়ি নি।", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                } else {
                    items(leaderboardPlayers) { player ->
                        val regDateStr = remember(player.joiningTimestamp) {
                            if (player.joiningTimestamp == 0L) {
                                "১৪ জুন ২০২৬, ১২:১৫ PM"
                            } else {
                                val date = java.util.Date(player.joiningTimestamp)
                                java.text.SimpleDateFormat("dd MMMM yyyy, hh:mm a", java.util.Locale.ROOT).format(date)
                            }
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = player.name, color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
                                        Text(text = "আসল নাম: ${player.realName.ifBlank { "N/A" }}", color = Color.LightGray, fontSize = 11.sp)
                                        Text(text = "গ্রাম/পাড়া: ${player.village.ifBlank { "N/A" }}", color = Color.LightGray, fontSize = 11.sp)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = "ক্রনিক সিরিয়াল #${player.serialNumber}", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color.Black.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("ফ্রি ফায়ার UID:", color = Color.Gray, fontSize = 9.sp)
                                        Text(player.playerUid, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                    Column {
                                        Text("যোগাযোগ নম্বর:", color = Color.Gray, fontSize = 9.sp)
                                        Text(player.phone.ifBlank { "N/A" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("ওয়ালেট ব্যালেন্স:", color = Color.Gray, fontSize = 9.sp)
                                        Text("৳ ${player.balance}", color = Color(0xFF00E676), fontWeight = FontWeight.Black, fontSize = 11.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = "📬 যোগদানের সময় ও তারিখ: $regDateStr",
                                    color = Color.LightGray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            } else if (adminSubTab == 3) {
                // 4. Standings Result Inputting tab
                if (leaderboardPlayers.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("ফলাফল বসানোর জন্য কোনো প্লেয়ার পাওয়া যায়নি!", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                } else {
                    items(leaderboardPlayers) { player ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(player.name, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                                    Text("সিরিয়্যাল আইডি: #${player.serialNumber}", color = Color.LightGray, fontSize = 11.sp)
                                    Text("রেকর্ড: ${player.wins} জয় - ${player.losses} হার", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("জয় (Win)", color = Color.LightGray, fontSize = 10.sp)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(
                                                onClick = {
                                                    if (player.wins > 0) {
                                                        onUpdateLeaderboardPlayer(player.copy(wins = player.wins - 1))
                                                    }
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Minus", tint = Color.Red, modifier = Modifier.size(16.dp))
                                            }
                                            Text("${player.wins}", color = Color.White, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 4.dp), fontSize = 12.sp)
                                            IconButton(
                                                onClick = {
                                                    onUpdateLeaderboardPlayer(player.copy(wins = player.wins + 1))
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Default.AddCircleOutline, contentDescription = "Plus", tint = Color.Green, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }

                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("হার (Loss)", color = Color.LightGray, fontSize = 10.sp)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(
                                                onClick = {
                                                    if (player.losses > 0) {
                                                        onUpdateLeaderboardPlayer(player.copy(losses = player.losses - 1))
                                                    }
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Minus", tint = Color.Red, modifier = Modifier.size(16.dp))
                                            }
                                            Text("${player.losses}", color = Color.White, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 4.dp), fontSize = 12.sp)
                                            IconButton(
                                                onClick = {
                                                    onUpdateLeaderboardPlayer(player.copy(losses = player.losses + 1))
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Default.AddCircleOutline, contentDescription = "Plus", tint = Color.Green, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }

                                    OutlinedButton(
                                        onClick = { editingPlayerToUpdate = player },
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        modifier = Modifier.height(26.dp),
                                        shape = RoundedCornerShape(4.dp),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                                    ) {
                                        Text("ডিটেইলস", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (adminSubTab == 4) {
                // 5. Account Profit Tracker & Trial Recharge Dashboard
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("📊 ইন্টিগ্রেটেড আর্থিক ট্র্যাকার ও হিসাব", fontWeight = FontWeight.ExtraBold, color = Color.White, fontSize = 15.sp)

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(modifier = Modifier.weight(1f).background(Color.Black.copy(alpha = 0.2f), RoundedCornerShape(8.dp)).padding(12.dp)) {
                                    Text("মোট ডিপোজিট (Approved)", color = Color.Gray, fontSize = 10.sp)
                                    Text("৳ $totalDepositsMoney", color = Color(0xFF00E676), fontWeight = FontWeight.Black, fontSize = 16.sp)
                                }
                                Column(modifier = Modifier.weight(1f).background(Color.Black.copy(alpha = 0.2f), RoundedCornerShape(8.dp)).padding(12.dp)) {
                                    Text("মোট উইথড্র (Approved)", color = Color.Gray, fontSize = 10.sp)
                                    Text("৳ $totalWithdrawnMoney", color = Color.Yellow, fontWeight = FontWeight.Black, fontSize = 16.sp)
                                }
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(modifier = Modifier.weight(1f).background(Color.Black.copy(alpha = 0.2f), RoundedCornerShape(8.dp)).padding(12.dp)) {
                                    Text("মোট টিকিট রেভিনিউ", color = Color.Gray, fontSize = 10.sp)
                                    Text("৳ $totalTicketSold", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
                                }
                                Column(modifier = Modifier.weight(1f).background(Color.Black.copy(alpha = 0.2f), RoundedCornerShape(8.dp)).padding(12.dp)) {
                                    Text("ক্রীড়া প্রাইজ বিতরণী", color = Color.Gray, fontSize = 10.sp)
                                    Text("৳ $totalPrizesDistributed", color = Color.Red, fontWeight = FontWeight.Black, fontSize = 16.sp)
                                }
                            }

                            Column(modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), RoundedCornerShape(8.dp)).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("অ্যাপ নেট লাভ / প্রফিট (টিকিট রেভিনিউ - টুর্নামেন্ট প্রাইজ)", color = Color.LightGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("৳ $appCorporateEarnings", color = if (appCorporateEarnings >= 0) Color(0xFF00E676) else Color.Red, fontWeight = FontWeight.Black, fontSize = 24.sp)
                                Text("ফ্রি ট্রায়াল ব্যালেন্স বিতরণী: ৳ $trialAdditions", color = Color.LightGray, fontSize = 10.sp)
                            }
                        }
                    }
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        var giftAmount by remember { mutableStateOf("৫০০") }

                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("ফ্রি ট্রায়াল ব্যালেন্স কুইক রিচার্জ", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                            Text(
                                text = "এই রিচার্জটি সম্পূর্ণ ফ্রি টেস্ট ব্যালেন্স এবং কোনো পেমেন্ট গেটওয়ে ছাড়াই টেস্টিং উদ্দেশ্যে কয়েন ওয়ালেটে জমা করবে।",
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )

                            OutlinedTextField(
                                value = giftAmount,
                                onValueChange = { giftAmount = it },
                                label = { Text("কয়েন বা টাকার পরিমাণ") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Button(
                                onClick = {
                                    val amt = giftAmount.replace("১","1").replace("২","2").replace("৩","3").replace("৪","4").replace("৫","5").replace("৬","6").replace("৭","7").replace("৮","8").replace("৯","9").replace("০","0").toDoubleOrNull() ?: 500.0
                                    onGiveTrialBalance(amt)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.AddCircleOutline, contentDescription = "Add cash")
                                    Text("ওয়ালেটে কয়েন যোগ করুন", fontWeight = FontWeight.Bold, color = Color.Black)
                                }
                            }
                        }
                    }
                }
            } else if (adminSubTab == 5) {
                // 6. Notice Board Management Tab
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF131622)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "📣 নতুন ঘোষণা বা নোটিশ প্রকাশ করুন",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            var noticeTitleText by remember { mutableStateOf("") }
                            var noticeContentText by remember { mutableStateOf("") }
                            
                            OutlinedTextField(
                                value = noticeTitleText,
                                onValueChange = { noticeTitleText = it },
                                label = { Text("নোটিশের শিরোনাম (Title)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("notice_title_input")
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            OutlinedTextField(
                                value = noticeContentText,
                                onValueChange = { noticeContentText = it },
                                label = { Text("নোটিশের বিস্তারিত বিবরণ (Content)") },
                                modifier = Modifier.fillMaxWidth().height(100.dp).testTag("notice_content_input")
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            Button(
                                onClick = {
                                    if (noticeTitleText.isNotBlank() && noticeContentText.isNotBlank()) {
                                        onAddNotice(noticeTitleText.trim(), noticeContentText.trim())
                                        noticeTitleText = ""
                                        noticeContentText = ""
                                        Toast.makeText(context, "অফিশিয়াল নোটিশটি সফলভাবে প্রকাশ করা হয়েছে! 🚀", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "শিরোনাম এবং বিবরণ সম্পূর্ণ করুন!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("publish_notice_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Text("নোটিশ পোস্ট করুন ✨", fontWeight = FontWeight.Bold, color = Color.Black)
                            }
                        }
                    }
                }
                
                item {
                    Text(
                        text = "📋 বর্তমান জারি করা নোটিশসমূহ (${notices.size})",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                }
                
                if (notices.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("কোনো সচল নোটিশ নেই!", color = Color.LightGray, fontSize = 11.sp)
                            }
                        }
                    }
                } else {
                    items(notices) { notice ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF10121C)),
                            border = BorderStroke(1.dp, Color.Gray.copy(alpha = 0.2f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(notice.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(
                                            "ভোট: +${notice.likes} | -${notice.dislikes}",
                                            color = Color.Gray,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                    
                                    IconButton(
                                        onClick = {
                                            onDeleteNotice(notice.id)
                                            Toast.makeText(context, "নোটিশটি সফলভাবে মুছে ফেলা হয়েছে।", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete Notice",
                                            tint = Color(0xFFEF5350)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    notice.content,
                                    color = Color.LightGray,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }

        // Leaderboard Player detail values modification dialog
        editingPlayerToUpdate?.let { player ->
            var editWins by remember { mutableStateOf(player.wins.toString()) }
            var editLosses by remember { mutableStateOf(player.losses.toString()) }
            var editBalance by remember { mutableStateOf(player.balance.toString()) }

            Dialog(onDismissRequest = { editingPlayerToUpdate = null }) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("🛠️ প্লেয়ার রেকর্ড মডিফায়ার", fontWeight = FontWeight.Black, color = Color.White, fontSize = 16.sp)
                        Text("খেলোয়াড়: ${player.name}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp)

                        OutlinedTextField(
                            value = editWins,
                            onValueChange = { editWins = it },
                            label = { Text("মোট জয় (Wins)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = editLosses,
                            onValueChange = { editLosses = it },
                            label = { Text("মোট হার (Losses)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = editBalance,
                            onValueChange = { editBalance = it },
                            label = { Text("ওয়ালেট ব্যালেন্স (৳)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { editingPlayerToUpdate = null },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("বাতিল")
                            }

                            Button(
                                onClick = {
                                    val finalWins = editWins.toIntOrNull() ?: player.wins
                                    val finalLosses = editLosses.toIntOrNull() ?: player.losses
                                    val finalBalance = editBalance.toDoubleOrNull() ?: player.balance

                                    onUpdateLeaderboardPlayer(
                                        player.copy(
                                            wins = finalWins,
                                            losses = finalLosses,
                                            balance = finalBalance
                                        )
                                    )
                                    editingPlayerToUpdate = null
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Text("সংরক্ষণ")
                            }
                        }
                    }
                }
            }
        }
    }
}
