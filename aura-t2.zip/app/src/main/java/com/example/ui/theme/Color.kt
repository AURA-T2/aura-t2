package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Gaming / Cyberpunk "AURA" theme colors
val AuraBackground = Color(0xFF0B0C10)
val AuraSurface = Color(0xFF161922)
val AuraSurfaceVariant = Color(0xFF242936)

val AuraPrimary = Color(0xFFFF4F1A) // Electric Aura Red-Orange
val AuraSecondary = Color(0xFF00E5FF) // Cyber Neon Cyan
val AuraTertiary = Color(0xFFFFD600) // Esport Trophy Gold

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF9EADB9)
val AccentGreen = Color(0xFF00E676)
val AccentRed = Color(0xFFFF1744)

// Backward compatible placeholders for theme templates
val Purple80 = AuraPrimary
val PurpleGrey80 = AuraSecondary
val Pink80 = AuraTertiary

val Purple40 = AuraPrimary
val PurpleGrey40 = AuraSecondary
val Pink40 = AuraTertiary
