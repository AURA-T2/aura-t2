package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.MatchEntity
import com.example.data.TransactionEntity
import com.example.data.TournamentRepository
import com.example.data.UserWalletEntity
import com.example.data.LeaderboardPlayerEntity
import com.example.data.NoticeEntity
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppTab {
    HOME, TOURNAMENTS, LEADERBOARD, RESULTS, WALLET, RULES_SUPPORT, ADMIN
}

sealed interface TournamentUiState {
    object Loading : TournamentUiState
    data class Success(
        val matches: List<MatchEntity>,
        val wallet: UserWalletEntity,
        val transactions: List<TransactionEntity>,
        val leaderboardPlayers: List<LeaderboardPlayerEntity>,
        val notices: List<NoticeEntity>
    ) : TournamentUiState
}

class TournamentViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = TournamentRepository(database.tournamentDao())

    val uiState: StateFlow<TournamentUiState> = combine(
        repository.allMatches,
        repository.userWallet,
        repository.allTransactions,
        repository.allLeaderboardPlayers,
        repository.allNotices
    ) { matches, wallet, transactions, leaderboardPlayers, notices ->
        TournamentUiState.Success(
            matches = matches,
            wallet = wallet ?: UserWalletEntity(
                inGameName = "",
                playerUid = "",
                balance = 120.0,
                phone = ""
            ),
            transactions = transactions,
            leaderboardPlayers = leaderboardPlayers,
            notices = notices
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TournamentUiState.Loading
    )

    private val _currentTab = MutableStateFlow(AppTab.HOME)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    private val _eventMessage = MutableSharedFlow<String>()
    val eventMessage: SharedFlow<String> = _eventMessage.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.prepopulateDatabase()
        }
    }

    fun selectTab(tab: AppTab) {
        _currentTab.value = tab
    }

    fun updateProfile(realName: String, village: String, uid: String, ign: String, phone: String) {
        viewModelScope.launch {
            if (realName.isBlank() || village.isBlank() || uid.isBlank() || ign.isBlank() || phone.isBlank()) {
                _eventMessage.emit("সবগুলো ঘর সঠিকভাবে পূরণ করুন!")
                return@launch
            }
            repository.updateProfile(realName, village, uid, ign, phone)
            _eventMessage.emit("নিবন্ধন ও প্রোফাইল সফলভাবে সম্পন্ন হয়েছে!")
        }
    }

    fun registerForMatch(match: MatchEntity, playerName: String, squadName: String?) {
        viewModelScope.launch {
            val state = uiState.value
            if (state !is TournamentUiState.Success) return@launch
            val wallet = state.wallet

            if (wallet.playerUid.isBlank() || wallet.inGameName.isBlank()) {
                _eventMessage.emit("অনুগ্রহ করে প্রোফাইল ট্যাবে গিয়ে প্রোফাইল সেটআপ করুন!")
                return@launch
            }
            if (wallet.balance < match.entryFee) {
                _eventMessage.emit("পর্যাপ্ত ব্যালেন্স নেই! অনুগ্রহ করে প্রথমে রিচার্জ করুন।")
                return@launch
            }
            if (match.joinedSlots >= match.totalSlots) {
                _eventMessage.emit("দুঃখিত, এই টুর্নামেন্টের সব আসন পূর্ণ হয়ে গেছে!")
                return@launch
            }

            val success = repository.registerForMatch(match, wallet, playerName, squadName)
            if (success) {
                _eventMessage.emit("অভিনন্দন! আপনি '${match.title}' ম্যাচে অংশ নিয়েছেন!")
            } else {
                _eventMessage.emit("নিবন্ধন ব্যর্থ হয়েছে! আবার চেষ্টা করুন।")
            }
        }
    }

    fun depositMoney(amount: Double, method: String, senderNumber: String, transactionId: String) {
        viewModelScope.launch {
            if (amount <= 0) {
                _eventMessage.emit("সঠিক টাকার পরিমাণ টাইপ করুন!")
                return@launch
            }
            if (senderNumber.isBlank() || senderNumber.length < 11) {
                _eventMessage.emit("সঠিক স্যান্ডার মোবাইল নম্বর দিন!")
                return@launch
            }
            if (transactionId.isBlank() || transactionId.length < 4) {
                _eventMessage.emit("সঠিক ট্রানজেকশন আইডি টাইপ করুন!")
                return@launch
            }

            val state = uiState.value
            if (state !is TournamentUiState.Success) return@launch
            val wallet = state.wallet

            val success = repository.depositMoney(wallet, amount, method, senderNumber, transactionId)
            if (success) {
                _eventMessage.emit("অনুরোধ সফল! আপনার ট্রানজেকশন আইডি ভেরিফাই করে ব্যালেন্স যোগ করা হবে।")
            } else {
                _eventMessage.emit("লেনদেন ব্যর্থ হয়েছে!")
            }
        }
    }

    fun withdrawMoney(amount: Double, method: String, receiverNumber: String) {
        viewModelScope.launch {
            if (amount <= 0) {
                _eventMessage.emit("সঠিক টাকার পরিমাণ টাইপ করুন!")
                return@launch
            }
            if (receiverNumber.isBlank() || receiverNumber.length < 11) {
                _eventMessage.emit("সঠিক মোবাইল ব্যাংকিং নম্বর দিন!")
                return@launch
            }

            val state = uiState.value
            if (state !is TournamentUiState.Success) return@launch
            val wallet = state.wallet

            if (wallet.balance < amount) {
                _eventMessage.emit("দুঃখিত, আপনার ওয়ালেটে পর্যাপ্ত পরিমাণ ব্যালেন্স নেই!")
                return@launch
            }

            val success = repository.withdrawMoney(wallet, amount, method, receiverNumber)
            if (success) {
                _eventMessage.emit("$amount টাকা উত্তোলনের জন্য আবেদন জমা নেওয়া হয়েছে (Pending)!")
            } else {
                _eventMessage.emit("উত্তোলন ব্যর্থ হয়েছে!")
            }
        }
    }

    fun approveTransaction(txnId: Int) {
        viewModelScope.launch {
            val success = repository.approveTransaction(txnId)
            if (success) {
                _eventMessage.emit("লেনদেনটি সফলভাবে অনুমোদন (Approve) করা হয়েছে!")
            } else {
                _eventMessage.emit("অনুমোদন ব্যর্থ হয়েছে!")
            }
        }
    }

    fun rejectTransaction(txnId: Int) {
        viewModelScope.launch {
            val success = repository.rejectTransaction(txnId)
            if (success) {
                _eventMessage.emit("লেনদেনটি বাতিল (Reject) করা হয়েছে!")
            } else {
                _eventMessage.emit("বাতিলকরণ ব্যর্থ হয়েছে!")
            }
        }
    }

    fun addTournament(match: MatchEntity) {
        viewModelScope.launch {
            repository.addTournament(match)
            _eventMessage.emit("টুর্নামেন্টটি সফলভাবে যোগ করা হয়েছে!")
        }
    }

    fun addTrialBalance(amount: Double) {
        viewModelScope.launch {
            val success = repository.addTrialBalance(amount)
            if (success) {
                _eventMessage.emit("ওয়ালেটে ৳$amount ট্রায়াল ব্যালেন্স যোগ করা হয়েছে!")
            } else {
                _eventMessage.emit("ব্যালেন্স যোগ করা ব্যর্থ হয়েছে!")
            }
        }
    }

    fun updateLeaderboardPlayer(player: LeaderboardPlayerEntity) {
        viewModelScope.launch {
            repository.updateLeaderboardPlayer(player)
            _eventMessage.emit("লিডারবোর্ড তথ্য সফলভাবে আপডেট হয়েছে!")
        }
    }

    fun addNotice(title: String, content: String) {
        viewModelScope.launch {
            if (title.isBlank() || content.isBlank()) {
                _eventMessage.emit("নোটিসের শিরোনাম এবং বিস্তারিত সঠিকভাবে লিখুন!")
                return@launch
            }
            repository.addNotice(NoticeEntity(title = title, content = content))
            _eventMessage.emit("নতুন নোটিস সফলভাবে পোস্ট করা হয়েছে!")
        }
    }

    fun deleteNotice(id: Int) {
        viewModelScope.launch {
            repository.deleteNotice(id)
            _eventMessage.emit("নোটিসটি সফলভাবে ডিলিট করা হয়েছে!")
        }
    }

    fun voteNotice(noticeId: Int, isLike: Boolean, playerUid: String) {
        viewModelScope.launch {
            if (playerUid.isBlank()) {
                _eventMessage.emit("ভোট দিতে অনুগ্রহ করে প্রোফাইল ট্যাবে গিয়ে প্রোফাইল সেটআপ করুন!")
                return@launch
            }
            val state = uiState.value
            if (state !is TournamentUiState.Success) return@launch
            val notice = state.notices.find { it.id == noticeId } ?: return@launch
            
            val votedList = notice.votedUserIds.split(",").filter { it.isNotBlank() }
            if (votedList.contains(playerUid)) {
                _eventMessage.emit("আপনি ইতিমধ্যে এই নোটিশে ভোট দিয়েছেন!")
                return@launch
            }

            val newLikes = if (isLike) notice.likes + 1 else notice.likes
            val newDislikes = if (!isLike) notice.dislikes + 1 else notice.dislikes
            val newVotedList = if (notice.votedUserIds.isBlank()) playerUid else "${notice.votedUserIds},$playerUid"

            repository.updateNotice(notice.copy(likes = newLikes, dislikes = newDislikes, votedUserIds = newVotedList))
            _eventMessage.emit("আপনার ম্যুলবান ভোট সফলভাবে জমা হয়েছে!")
        }
    }
}
